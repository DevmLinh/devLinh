<?php
require_once('../admin/config.php');




if (!isset($_SESSION['username_ad'])) {
    header("location: admin");
}








$masp = "SP_" . get_random_string(5);

if (!isset($_POST['close_formthem']) and !isset($_POST['open_formthem']) and !isset($_SESSION['_formthem'])) {
    $_SESSION['_formthem'] = 'none';
} else {

    if (isset($_POST['close_formthem'])) {
        $_SESSION['_formthem'] = 'none';
        header("location: ../san-pham");
    }

    if (isset($_POST['open_formthem'])) {
        $_SESSION['_formthem'] = 'block';
        header("location: ../san-pham");
    }
}

if (!isset($_SESSION['_page_sp'])) {
    $_SESSION['_page_sp'] = '1';
}

if (isset($_GET['page'])) {
    $_SESSION['_page_sp'] = $_GET['page'];
}


if (isset($_GET['masp'])) {
    $masp_delete = $_GET['masp'];
    $data_sp = $ketnoi->query("SELECT * FROM `san_pham` WHERE `ma_sp` = '" . $masp_delete . "'")->fetch_array();

    if ($data_sp['id_sp'] != '') {
        if ($masp_delete != '') {
?>
            <script>
                if (confirm('Bạn có chắc muốn xóa sản phẩm [ <?= $data_sp['ten_sp'] ?> | <?= $data_sp['ma_sp'] ?> ] không?')) {
                    <?php
                    $sql_ = "DELETE FROM `san_pham` WHERE `ma_sp` = '" . $masp_delete . "'";
                    $xoa_sp = $ketnoi->query($sql_);
                    if ($xoa_sp) {
                        echo "confirm('Xóa [ " . $data_sp['ten_sp'] . " | " . $data_sp['ma_sp'] . " ] thành công')";
                    } else {
                        echo "confirm('Xóa [ " . $data_sp['ten_sp'] . " | " . $data_sp['ma_sp'] . " ] thất bại')";
                    }
                    ?>
                } else {
                    // false
                }
            </script>
<?php
        }
    } else {
        echo "<script>confirm('Mã sản phẩm [ " . $masp_delete . " ] không tồn tại.');</script>";
    }
    echo '<meta http-equiv="refresh" content="0;url=../san-pham">';
}



$link_png = "";

$ma_sp = $masp;
$ten_sp = '';
$mota_sp = '';
$sl_sp = '';
$gia_sp = '';

if (isset($_POST['them_sp_'])) {

    $ma_sp  = $_POST['ma_sp'];
    $ten_sp = $_POST['ten_sp'];
    $mota_sp = $_POST['mota_sp'];
    $sl_sp  = $_POST['sl_sp'];
    $gia_sp = $_POST['gia_sp'];

    //echo "xin chao cac ban";
    $link_png = "";
    $total = '';
    if (isset($_FILES['upload'])) {
        $total = count($_FILES['upload']['name']);
        // Loop through each file
        if ($total == 3) {
            for ($i = 0; $i < $total; $i++) {
                //Get the temp file path
                $tmpFilePath = $_FILES['upload']['tmp_name'][$i];
                //echo $tmpFilePath;
                //Make sure we have a file path
                if ($tmpFilePath != "") {
                    //Setup our new file path
                    //$file_name =  loc_kytu($_FILES['upload']['name'][$i]).".png";
                    while (true) {
                        $file_name = "SP_" . $ma_sp . "_" . ($i + 1) . ".png";
                        if (!file_exists("uploads/" . $file_name)) {
                            break;
                        }
                    }
                    $newFilePath = 'uploads/' . $file_name;
                    //Upload the file into the temp dir
                    if (move_uploaded_file($tmpFilePath, $newFilePath)) {
                        //Handle other code here
                    }
                    $link_anh = '../admin/uploads/' . $file_name;
                    if ($i == 0) {
                        $link_png = $link_anh;
                    } else {
                        $link_png = $link_png . ", " . $link_anh;
                    }
                }
            }
        }
    }
    //echo $link_png;

    if ($total != '' and $total != 0) {
        if ($total !== 3) {
            echo "<script>confirm('Vui lòng tải lên 3 File hình ảnh.');</script>";
            $total = '';
        } else {

            $check_ma_sp = mysqli_num_rows(mysqli_query($ketnoi, "SELECT * FROM san_pham WHERE ma_sp ='$ma_sp'"));
            if ($check_ma_sp != 0) {
                echo "<script>confirm('Mã sản phẩm đã tồn tại.');</script>";
                $_POST['ma_sp'] = $masp;
            } else {
                $sql_ = "INSERT INTO `san_pham`(`ma_sp`, `anh_sp`, `ten_sp`, `mota_sp`, `gia_sp`, `soluong_sp`, `daban_sp`, `ngay_sp`, `trangthai_sp`) 
                                    VALUES ('" . $ma_sp . "','" . $link_png . "','" . $ten_sp . "','" . $mota_sp . "','" . $gia_sp . "','" . $sl_sp . "','0','" . date("Y-m-d H:i:s") . "','1')";
                $tao_sp = $ketnoi->query($sql_);
                if ($tao_sp) {
                    echo "<script>confirm('Thêm sản phẩm thành công.');</script>";
                    echo '<meta http-equiv="refresh" content="1;url=../san-pham">';
                } else {
                    echo "<script>confirm('Thêm sản phẩm thất bại.');</script>";
                }
            }
        }
    } else {
        echo "<script>confirm('Vui lòng tải lên 3 File hình ảnh.');</script>";
        $total = '';
    }
}




$_SESSION['_formsua'] = "none";
if (isset($_GET['chinhsua'])) {
    $masp_update = $_GET['chinhsua'];
    $data_sp = $ketnoi->query("SELECT * FROM `san_pham` WHERE `ma_sp` = '" . $masp_update . "'")->fetch_array();

    if ($data_sp['id_sp'] != '') {
        $ma_sp = $masp_update;
        $ten_sp = $data_sp['ten_sp'];
        $mota_sp = $data_sp['mota_sp'];
        $sl_sp  = $data_sp['soluong_sp'];
        $gia_sp = $data_sp['gia_sp'];
        $trangthai_sp = $data_sp['trangthai_sp'];
        $_SESSION['_formsua'] = "block";
        $_SESSION['_formthem'] = 'none';

        if ($trangthai_sp == '0') {
            $ttsp = 'checked';
            $ttsp2 = '';
        } else {
            $ttsp2 = 'checked';
            $ttsp = '';
        }
    } else {
        echo "<script>confirm('Mã sản phẩm [ " . $masp_update . " ] không tồn tại.');</script>";
    }
}


if (isset($_POST['sua_sp_'])) {
    $ma_sp = $masp_update;
    if ($ma_sp != '') {
        $data_sp = $ketnoi->query("SELECT * FROM `san_pham` WHERE `ma_sp` = '" . $ma_sp . "'")->fetch_array();

        $ten_sp = $_POST['ten_sp'];
        $mota_sp = $_POST['mota_sp'];
        $sl_sp  = $_POST['sl_sp'];
        $gia_sp = $_POST['gia_sp'];
        $trangthai_sp = $_POST['trangthai_sp'];
        //echo $trangthai_sp;

        $link_png = "";
        $total = '';
        $update_png = '';
        if (isset($_FILES['upload'])) {
            $total = count($_FILES['upload']['name']);
            if ($total != 0) {
                // Loop through each file
                if ($total == 3) {
                    for ($i = 0; $i < $total; $i++) {
                        //Get the temp file path
                        $tmpFilePath = $_FILES['upload']['tmp_name'][$i];
                        //echo $tmpFilePath;
                        //Make sure we have a file path
                        if ($tmpFilePath != "") {
                            //Setup our new file path
                            //$file_name =  loc_kytu($_FILES['upload']['name'][$i]).".png";
                            while (true) {
                                $file_name = "SP_" . $ma_sp . "_" . ($i + 1) . ".png";

                                unlink("uploads/" . $file_name);
                                if (!file_exists("uploads/" . $file_name)) {
                                    break;
                                }
                            }
                            $newFilePath = 'uploads/' . $file_name;
                            //Upload the file into the temp dir
                            if (move_uploaded_file($tmpFilePath, $newFilePath)) {
                                //Handle other code here
                            }
                            $link_anh = '../admin/uploads/' . $file_name;
                            if ($i == 0) {
                                $link_png = $link_anh;
                            } else {
                                $link_png = $link_png . ", " . $link_anh;
                            }
                        }
                    }
                    $update_png = "`anh_sp`='" . $link_png . "',";
                }
            }
        }
        $update_tensp = '';
        if ($ten_sp != $data_sp['ten_sp']) {
            $update_tensp = "`ten_sp`='" . $ten_sp . "',";
        }
        $update_motasp = '';
        if ($mota_sp != $data_sp['mota_sp']) {
            $update_motasp = "`mota_sp`='" . $mota_sp . "',";
        }
        $update_giasp = '';
        if ($gia_sp != $data_sp['gia_sp']) {
            $update_giasp = "`gia_sp`='" . $gia_sp . "',";
        }
        $update_slsp = '';
        if ($sl_sp != $data_sp['soluong_sp']) {
            $update_slsp = "`soluong_sp`='" . $sl_sp . "',";
        }
        $update_ttsp = '';
        if ($trangthai_sp != $data_sp['trangthai_sp']) {
            $update_ttsp = "`trangthai_sp`='" . $trangthai_sp . "'";
        } else {
            $update_ttsp = "`trangthai_sp`='1'";
        }

        //UPDATE `san_pham` SET `ma_sp`='',`anh_sp`='',`ten_sp`='',`gia_sp`='',`soluong_sp`='',`trangthai_sp`='' WHERE `ma_sp` = '" . $masp_update . "'
        $sql_update = "UPDATE `san_pham` SET " . $update_png . $update_tensp .$update_motasp. $update_giasp . $update_slsp . $update_ttsp . " WHERE `ma_sp` = '" . $masp_update . "'";
        //echo $sql_update;
        $update_sp = $ketnoi->query($sql_update);
        if ($update_sp) {
            echo "<script>confirm('Cập nhật sản phẩm thành công.');</script>";
            echo '<meta http-equiv="refresh" content="1;url=../san-pham">';
        } else {
            echo "<script>confirm('Cập nhật sản phẩm thất bại.');</script>";
        }
    } else {
        echo "<script>confirm('Mã sản phẩm không hợp lệ.');</script>";
    }
}




function get_random_string($length)
{
    $valid_chars = "QWERTYUIOPASDFGHJKLZXCVBNM1234567890";
    $random_string = "";
    $num_valid_chars = strlen($valid_chars);
    for ($i = 0; $i < $length; $i++) {
        $random_pick = mt_Rand(1, $num_valid_chars);
        $random_char = $valid_chars[$random_pick - 1];
        $random_string .= $random_char;
    }
    return $random_string;
}





?>


<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>The row || Asbab - Mẫu HTML5 thương mại điện tử</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Place favicon.ico in the root directory -->
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">


    <!-- All css files are included here. -->
    <!-- Bootstrap fremwork main css -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- Owl Carousel min css -->
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">
    <!-- This core.css file contents all plugings css file. -->
    <link rel="stylesheet" href="../css/core.css">
    <!-- Theme shortcodes/elements style -->
    <link rel="stylesheet" href="../css/shortcode/shortcodes.css">
    <!-- Theme main style -->
    <link rel="stylesheet" href="../style.css">
    <!-- Responsive css -->
    <link rel="stylesheet" href="../css/responsive.css">
    <!-- User style -->
    <link rel="stylesheet" href="../css/custom.css">


    <!-- Modernizr JS -->
    <script src="../js/vendor/modernizr-3.5.0.min.js"></script>


    <style>
        .table-content table th {
            padding: 10px 5px;
        }
    </style>
</head>

<body>
    <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>error time</strong> browser. Please <a href="http://browsehappy.com/">nâng cấp trình duyệt của bạn</a>để cải thiện trải nghiệm của bạn.</p>
    <![endif]-->

    <!-- Body main wrapper start -->
    <div class="wrapper">
        <!-- Start Header Style -->
        <?php require_once('../admin/header.php'); ?>
        <!-- End Header Area -->


        <!-- End Bradcaump area -->
        <!-- cart-main-area start -->
        <div class="cart-main-area ptb--100 bg__white">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">


                        <form action="" method="POST">

                            <div class="row">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="buttons-cart--inner">
                                        <div class="buttons-cart">
                                            <?php if ($_SESSION['_formthem'] == 'none') { ?>
                                                <button type="submit" class="fv-btn" name="open_formthem">THÊM MỚI SẢN PHẨM</button>
                                            <?php } else { ?>

                                                <button type="submit" class="fv-btn" name="close_formthem">
                                                    <i class="icon-close icons" style="font-size: 25px;"></i>
                                                </button>

                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>

                        <div id="FORM_THEM" style="display:<?= $_SESSION['_formthem'] ?>;">
                            <form action="" method="post" enctype="multipart/form-data">
                                <div class="single-contact-form">
                                    <label>Mã sản phẩm: </label>
                                    <div class="contact-box subject">
                                        <input type="text" name="ma_sp" placeholder="Mã sản phẩm*" value="<?= $ma_sp ?>">
                                    </div>
                                </div>
                                <div class="single-contact-form">
                                    <div class="contact-box subject">
                                        <label>Thêm 3 ảnh: </label>
                                        <input type="file" name="upload[]" placeholder="*" multiple="multiple" style="padding-top: 18px;">
                                    </div>
                                </div>
                                <div class="single-contact-form">
                                    <label>Tên sản phẩm: </label>
                                    <div class="contact-box subject">
                                        <input type="text" name="ten_sp" placeholder="Nhập tên sản phẩm*" value="<?= $ten_sp ?>">
                                    </div>
                                </div>
                                <div class="single-contact-form">
                                    <label>Mô tả sản phẩm: </label>
                                    <div class="contact-box subject">
                                        <textarea name="mota_sp" style="    background: #ffffff; border: 1px solid #bebebe" placeholder="Nhập mô tả sản phẩm*"><?= $mota_sp ?></textarea>
                                    </div>
                                </div>
                                <div class="single-contact-form">
                                    <label>Số lượng: </label>
                                    <div class="contact-box subject">
                                        <input type="number" name="sl_sp" placeholder="Số lượng sản phẩm*" value="<?= $sl_sp ?>">
                                    </div>
                                </div>
                                <div class="single-contact-form">
                                    <label>Giá bán: </label>
                                    <div class="contact-box subject">
                                        <input type="number" name="gia_sp" placeholder="Giá bán sản phẩm*" value="<?= $gia_sp ?>">
                                    </div>
                                </div>
                                <div class="contact-btn">
                                    <button type="submit" class="fv-btn" name="them_sp_">THỰC HIỆN THÊM</button>
                                </div><br /><br /><br /><br /><br />
                            </form>
                        </div>

                        <div id="FORM_THEM" style="display:<?= $_SESSION['_formsua'] ?>;">
                            <form action="" method="post" enctype="multipart/form-data">
                                <div class="single-contact-form">
                                    <label>Mã sản phẩm: </label>
                                    <div class="contact-box subject">
                                        <input type="text" name="ma_sp" placeholder="Mã sản phẩm*" value="<?= $ma_sp ?>" disabled>
                                    </div>
                                </div>
                                <div class="single-contact-form">
                                    <div class="contact-box subject">
                                        <label>Thêm 3 ảnh: </label>
                                        <input type="file" name="upload[]" placeholder="*" multiple="multiple" style="padding-top: 18px;">
                                    </div>
                                </div>
                                <div class="single-contact-form">
                                    <label>Tên sản phẩm: </label>
                                    <div class="contact-box subject">
                                        <input type="text" name="ten_sp" placeholder="Nhập tên sản phẩm*" value="<?= $ten_sp ?>">
                                    </div>
                                </div>
                                <div class="single-contact-form">
                                    <label>Mô tả sản phẩm: </label>
                                    <div class="contact-box subject">
                                        <textarea name="mota_sp" style="    background: #ffffff; border: 1px solid #bebebe" placeholder="Nhập mô tả sản phẩm*"><?= $mota_sp ?></textarea>
                                    </div>
                                </div>
                                <div class="single-contact-form">
                                    <div class=" subject">
                                        <label>Trạng thái: </label><br>&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;
                                        <input type="radio" name="trangthai_sp" id="0" value="0" <?= $ttsp ?>>
                                        <label for="0">Ẩn</label>&ensp;&ensp;&ensp;&ensp;&ensp;
                                        <input type="radio" name="trangthai_sp" id="1" value="1" <?= $ttsp2 ?>>
                                        <label for="1">Hiển thị</label>
                                    </div>
                                </div>
                                <div class="single-contact-form">
                                    <label>Số lượng: </label>
                                    <div class="contact-box subject">
                                        <input type="number" name="sl_sp" placeholder="Số lượng sản phẩm*" value="<?= $sl_sp ?>">
                                    </div>
                                </div>
                                <div class="single-contact-form">
                                    <label>Giá bán: </label>
                                    <div class="contact-box subject">
                                        <input type="number" name="gia_sp" placeholder="Giá bán sản phẩm*" value="<?= $gia_sp ?>">
                                    </div>
                                </div>
                                <div class="contact-btn">
                                    <button type="submit" class="fv-btn" name="sua_sp_">THỰC HIỆN SỬA</button>
                                </div><br /><br /><br /><br /><br />
                            </form>
                        </div>


                        <form action="" method="POST">
                            <div class="table-content table-responsive">
                                <table>
                                    <thead>
                                        <tr>
                                            <th class="product-thumbnail">STT</th>
                                            <th class="product-name">Mã SP</th>
                                            <th class="product-thumbnail">Hình ảnh</th>
                                            <th class="product-name">Tên SP</th>
                                            <th class="product-name">Mô tả</th>
                                            <th class="product-price">Giá bán</th>
                                            <th class="product-quantity">Số<BR>lượng</th>
                                            <th class="product-quantity">Trạng<BR>thái</th>
                                            <th class="product-remove"></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php

                                        $dau_page = ($_SESSION['_page_sp'] * 5) - 5;

                                        $query_sp = $ketnoi->query("SELECT * FROM `san_pham`");
                                        $stt = 0;
                                        while ($row = mysqli_fetch_array($query_sp)) {
                                            $stt++;
                                            if ($stt >= $dau_page and $stt <= $dau_page + 5) {

                                                $img = $row['anh_sp'];
                                                $img = explode(",", $img)[0];
                                                $trangthai = $row['trangthai_sp'];
                                                $hienthi = "Hiển thị";
                                                if ($trangthai == 0) {
                                                    $hienthi = "Ẩn";
                                                }

                                        ?>
                                                <tr>
                                                    <td class="product-thumbnail"><?= $stt ?></td>
                                                    <td class="product-price"><span class="amount"><?= $row['ma_sp'] ?></span></td>
                                                    <td class="product-thumbnail"><a href="../product-details/?masp=<?= $row['ma_sp'] ?>"><img src="<?= $img ?>" alt="product img" /></a></td>
                                                    <td class="product-name"><a href="../product-details/?masp=<?= $row['ma_sp'] ?>"><?= $row['ten_sp'] ?></a>
                                                    <td class="product-name"><a href="../product-details/?masp=<?= $row['ma_sp'] ?>"><?=sub_name($row['mota_sp'], 88) . '...';  ?></a>
                                                        <!--ul class="pro__prize">
                                                    <li class="old__prize">$82,5</li>
                                                    <li>$75,2</li>
                                                </ul-->
                                                    </td>
                                                    <td class="product-price"><span class="amount"><?= tien($row['gia_sp']) ?>đ</span></td>
                                                    <td class="product-price"><span class="amount"><?= $row['soluong_sp'] ?></span></td>
                                                    <td class="product-price"><span class="amount"><?= $hienthi ?></span></td>
                                                    <td class="product-remove">
                                                        <p>Sửa: <a href="../san-pham/?chinhsua=<?= $row['ma_sp'] ?>"><i class="icon-pencil icons" style="font-size: 15px; font-size: unset;"></i></a></p>
                                                        <p>Xóa: <a href="../san-pham/?masp=<?= $row['ma_sp'] ?>"><i class="icon-trash icons" style="font-size: 15px; font-size: unset;"></i></a></p>
                                                    </td>
                                                </tr>

                                        <?php }
                                        }
                                        ?>

                                    </tbody>
                                </table>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Start Pagenation -->
                <div class="row">
                    <div class="col-xs-12">
                        <ul class="htc__pagenation">
                            <li><a href="../san-pham/?page=<?= ($_SESSION['_page_sp'] - 1) ?>"><i class="zmdi zmdi-chevron-left"></i></a></li>
                            <?php
                            if ($_SESSION['_page_sp'] > 1) {
                                echo '<li ><a href="../san-pham/?page=' . ($_SESSION['_page_sp'] - 1) . '">' . ($_SESSION['_page_sp'] - 1) . '</a></li>';
                            }
                            ?>
                            <li class="active"><a href="../san-pham/?page=<?= ($_SESSION['_page_sp']) ?>"><?= ($_SESSION['_page_sp']) ?></a></li>
                            <?php
                            if ($stt > 9 and $_SESSION['_page_sp'] < ceil($stt / 5)) {
                                echo '<li ><a href="../san-pham/?page=' . ($_SESSION['_page_sp'] + 1) . '">' . ($_SESSION['_page_sp'] + 1) . '</a></li>';
                            }
                            ?>
                            <?php
                            if ($_SESSION['_page_sp'] + 1 < ceil($stt / 5)) {
                            ?>
                                <li><a href="">...</a></li>
                                <li><a href="../san-pham/?page=<?= ceil($stt / 5) ?>"><?= ceil($stt / 5) ?></a></li>
                            <?php } ?>
                            <li><a href="../san-pham/?page=<?= ($_SESSION['_page_sp'] + 1) ?>"><i class="zmdi zmdi-chevron-right"></i></a></li>
                        </ul>
                    </div>
                </div>
                <!-- End Pagenation -->
            </div>
        </div>
        <!-- cart-main-area end -->
        <!-- Start Brand Area -->
        <div class="htc__brand__area bg__cat--4">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="ht__brand__inner">
                            <ul class="brand__list owl-carousel clearfix">
                                <li><a href="#"><img src="../images/brand/1.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/2.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/3.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/4.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/5.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/5.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/1.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/2.png" alt="brand images"></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Brand Area -->
        <!-- Start Banner Area -->
        <div class="htc__banner__area">
            <ul class="banner__list owl-carousel owl-theme clearfix">
                <li><a href="../product-details"><img src="../images/banner/bn-3/1.jpg" alt="banner images"></a></li>
                <li><a href="../product-details"><img src="../images/banner/bn-3/2.jpg" alt="banner images"></a></li>
                <li><a href="../product-details"><img src="../images/banner/bn-3/3.jpg" alt="banner images"></a></li>
                <li><a href="../product-details"><img src="../images/banner/bn-3/4.jpg" alt="banner images"></a></li>
                <li><a href="../product-details"><img src="../images/banner/bn-3/5.jpg" alt="banner images"></a></li>
                <li><a href="../product-details"><img src="../images/banner/bn-3/6.jpg" alt="banner images"></a></li>
                <li><a href="../product-details"><img src="../images/banner/bn-3/1.jpg" alt="banner images"></a></li>
                <li><a href="../product-details"><img src="../images/banner/bn-3/2.jpg" alt="banner images"></a></li>
            </ul>
        </div>
        <!-- End Banner Area -->
        <!-- End Banner Area -->
        <!-- Start Footer Area -->
        <footer id="htc__footer">
            <!-- Start Footer Widget -->
            <div class="footer__container bg__cat--1">
                <div class="container">
                    <div class="row">
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-3 col-sm-6 col-xs-12">
                            <div class="footer">
                                <h2 class="title__line--2">Coming Up</h2>
                                <div class="ft__details">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisizing elit, sed do eiusmod tempor incididunt utlabore et dolore magna aliqua. Út cưng</p>
                                    <div class="ft__social__link">
                                        <ul class="social__link">
                                            <li><a href="#"><i class="icon-social-twitter icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-instagram icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-facebook icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-google icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-linkedin icons"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40">
                            <div class="footer">
                                <h2 class="title__line--2">Information</h2>
                                <div class="ft__inner">
                                    <ul class="ft__list">
                                        <li><a href="#">Về chúng tôi</a></li>
                                        <li><a href="#">Thông tin giao hàng</a></li>
                                        <li><a href="#">Chính sách bảo mật</a></li>
                                        <li><a href="#">Điều khoản & Điều kiện</a></li>
                                        <li><a href="#">sản xuất</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40 smt-40">
                            <div class="footer">
                                <h2 class="title__line--2">tài khoản của tôi</h2>
                                <div class="ft__inner">
                                    <ul class="ft__list">
                                        <li><a href="#">Tài khoản của tôi</a></li>
                                        <li><a href="../cart">Hàng hóa của tôi</a></li>
                                        <li><a href="#">Đăng nhập</a></li>
                                        <li><a href="../wishlist">danh sách yêu thích</a></li>
                                        <li><a href="../checkout">Thanh toán liên tục</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40 smt-40">
                            <div class="footer">
                                <h2 class="title__line--2">giao dịch của chúng tôi</h2>
                                <div class="ft__inner">
                                    <ul class="ft__list">
                                        <li><a href="#">Tài khoản của tôi</a></li>
                                        <li><a href="../cart">Hàng hóa của tôi</a></li>
                                        <li><a href="#">Đăng nhập</a></li>
                                        <li><a href="../wishlist">danh sách yêu thích</a></li>
                                        <li><a href="../checkout">Thanh toán liên tục</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-3 col-sm-6 col-xs-12 xmt-40 smt-40">
                            <div class="footer">
                                <h2 class="title__line--2">BẢN TIN</h2>
                                <div class="ft__inner">
                                    <div class="news__input">
                                        <input type="text" placeholder="Your Mail*">
                                        <div class="send__btn">
                                            <a class="fr__btn" href="#">Gửi thư</a>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                    </div>
                </div>
            </div>
            <!-- End Footer Widget -->
            <!-- Start Copyright Area -->
            <div class="htc__copyright bg__cat--5">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="copyright__inner">
                                <p>Copyright© <a href="https://freethemescloud.com/">Chủ đề miễn phí Đám mây</a>2018. Bảo lưu mọi quyền.</p>
                                <a href="#"><img src="../images/others/shape/paypol.png" alt="payment images"></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Copyright Area -->
        </footer>
        <!-- End Footer Style -->
    </div>
    <!-- Body main wrapper end -->

    <!-- Placed js at the end of the document so the pages load faster -->

    <script>

    </script>

    <!-- jquery latest version -->
    <script src="../js/vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap framework js -->
    <script src="../js/bootstrap.min.js"></script>
    <!-- All js plugins included in this file. -->
    <script src="../js/plugins.js"></script>
    <script src="../js/slick.min.js"></script>
    <script src="../js/owl.carousel.min.js"></script>
    <!-- Waypoints.min.js. -->
    <script src="../js/waypoints.min.js"></script>
    <!-- Main js file that contents all jQuery plugins activation. -->
    <script src="../js/main.js"></script>

</body>

</html>