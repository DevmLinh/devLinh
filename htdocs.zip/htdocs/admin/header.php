<header id="htc__header" class="htc__header__area header--one">
    <!-- Start Mainmenu Area -->
    <div id="sticky-header-with-topbar" class="mainmenu__wrap sticky__header">
        <div class="container">
            <div class="row">
                <div class="menumenu__container clearfix">
                    <div class="col-lg-2 col-md-2 col-sm-3 col-xs-5">
                        <div class="logo">
                            <a href="../trang-chu"><img src="../images/logo/5.png" alt="logo images"></a>
                        </div>
                    </div>
                    <div class="col-md-7 col-lg-8 col-sm-5 col-xs-3">
                        <nav class="main__menu__nav hidden-xs hidden-sm">
                            <ul class="main__menu">
                                <li><a href="../quan-ly">Trang Chủ</a></li>
                                <li><a href="../san-pham">Sản phẩm</a></li>
                                <li><a href="../don-dat-hang">Đơn hàng</a></li>
                                <li><a href="../trang-chu">Người dùng</a></li>
                            </ul>
                        </nav>

                        <div class="mobile-menu clearfix visible-xs visible-sm">
                            <nav id="mobile_dropdown">
                                <ul style="background-color: #d10000;">
                                    <li><a href="../quan-ly">Trang Chủ</a></li>
                                    <li><a href="../san-pham">Sản phẩm</a></li>
                                    <li><a href="../don-dat-hang">Đơn hàng</a></li>
                                    <li><a href="../trang-chu">Người dùng</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <div class="col-md-3 col-lg-2 col-sm-4 col-xs-4">
                        <div class="header__right">
                            <div class="header__account">
                                <ul class="main__menu">
                                    <li class="drop"><i class="icon-user icons"></i>
                                        <ul class="dropdown">
                                            <li><a href="../trang-chu">Người dùng</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mobile-menu-area"></div>

        </div>
    </div>
    <!-- End Mainmenu Area -->
</header>
<!-- End Header Area -->