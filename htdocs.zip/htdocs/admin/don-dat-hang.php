<?php
require_once('../admin/config.php');

if (!isset($_SESSION['_page_dh'])) {
    $_SESSION['_page_dh'] = '1';
}

if (isset($_GET['page'])) {
    $_SESSION['_page_dh'] = $_GET['page'];
}


$_SESSION['muahang'] = 0;
if (!isset($_SESSION['username_ad'])) {
    echo "<script>confirm('Bạn phải đăng nhập để thực hiện thao tác này.');</script>";
    echo '<script>window.location = "../admin";</script>';
}


if (isset($_GET['chinhsua']) and isset($_GET['soluong'])) {
    // $_SESSION['arrgiohang'][str_replace("ip", "", $_GET['chinhsua'])]["soluong"] = $_GET['soluong'];
    // echo '<script>window.location = "../checkout";</script>';
}

if (isset($_GET['tt_madon'])) {
    $madon_ = $_GET['tt_madon'];


    $loai = explode("_", $madon_)[2];
    $madon = str_replace("_" . $loai, "", $madon_);
    $sql = "";
    if ($loai == 1) {
        $sql = "UPDATE `muahang` SET `trangthai`='1' WHERE `madonhang` = '" . $madon . "'";
    } elseif ($loai == 2) {
        $sql = "UPDATE `muahang` SET `trangthai`='2' WHERE `madonhang` = '" . $madon . "'";
    } elseif ($loai == 3) {
        $sql = "UPDATE `muahang` SET `trangthai`='0' WHERE `madonhang` = '" . $madon . "'";
    }
    if ($sql != '') {
        $capnhat = $ketnoi->query($sql);
        if ($capnhat) {
            echo "<script>confirm('Dã cập nhật trạng thái.');</script>";
        }
    }
    echo '<meta http-equiv="refresh" content="0;url=../don-dat-hang">';
}





?>


<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Thanh toán || Asbab - Mẫu HTML5 thương mại điện tử</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Place favicon.ico in the root directory -->
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">


    <!-- All css files are included here. -->
    <!-- Bootstrap fremwork main css -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- Owl Carousel min css -->
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">
    <!-- This core.css file contents all plugings css file. -->
    <link rel="stylesheet" href="../css/core.css">
    <!-- Theme shortcodes/elements style -->
    <link rel="stylesheet" href="../css/shortcode/shortcodes.css">
    <!-- Theme main style -->
    <link rel="stylesheet" href="../style.css">
    <!-- Responsive css -->
    <link rel="stylesheet" href="../css/responsive.css">
    <!-- User style -->
    <link rel="stylesheet" href="../css/custom.css">


    <!-- Modernizr JS -->
    <script src="../js/vendor/modernizr-3.5.0.min.js"></script>

    <style>
        .wishlist-table table td {

            font-weight: 60;
            padding: 5px 5px;
            text-align: center;
        }
    </style>
</head>

<body>
    <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>error time</strong> browser. Please <a href="http://browsehappy.com/">nâng cấp trình duyệt của bạn</a>để cải thiện trải nghiệm của bạn.</p>
    <![endif]-->

    <!-- Body main wrapper start -->
    <div class="wrapper">
        <!-- Start Header Style -->
        <?php require_once('../admin/header.php'); ?>
        <!-- End Header Area -->
        <!-- Start Bradcaump area -->
        <div class="ht__bradcaump__area" style="background: rgba(0, 0, 0, 0) url(images/bg/5.jpg) no-repeat scroll center center / cover ;">
            <div class="ht__bradcaump__wrap">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="bradcaump__inner">
                                <nav class="bradcaump-inner">
                                    <a class="breadcrumb-item" href="../trang-chu">Trang Chủ</a>
                                    <span class="brd-separetor"><i class="zmdi zmdi-chevron-right"></i></span>
                                    <span class="breadcrumb-item active">Thanh toán liên tục</span>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Bradcaump area -->
        <!-- cart-main-area start -->
        <div class="checkout-wrap ptb--100">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="order-details" style="background-color: #e8e8e8;">
                            <h5 class="order-details__title">QUẢN LÝ ĐƠN HÀNG</h5>
                            <div class="wishlist-table table-responsive">
                                <table>
                                    <thead>
                                        <tr>
                                            <th class="product-thumbnail" style="width: 5px;"><span>STT</span></th>
                                            <th class="product-thumbnail" style="width: 590px;">Đơn hàng</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $dau_page_donhange = ($_SESSION['_page_dh'] * 3) - 3;

                                        $query_sp = $ketnoi->query("SELECT * FROM `muahang` ORDER BY `id` DESC");
                                        $stt = 0;

                                        while ($row = mysqli_fetch_array($query_sp)) {
                                            $stt++;
                                            if ($stt >= $dau_page_donhange and $stt <= $dau_page_donhange + 3) {
                                                $tongtien = 0;
                                                $sl_sp_1 = 0;

                                                $madon = $row['madonhang'];

                                                $taikhoan_kh = $row['taikhoan'];
                                                $user_kh = $ketnoi->query("SELECT * FROM `users` WHERE `taikhoan` = '$taikhoan_kh' ")->fetch_array();

                                                $json_hang = $row['json_hang'];
                                                $json_hang = json_decode($json_hang, true);
                                                $json_phi = $row['json_phi'];
                                                $json_phi = json_decode($json_phi, true);
                                                $phi_ship = $json_phi['phi_vanchuyen'];
                                                $tong_phi = $json_phi['phi_vanchuyen'];
                                                $thoigian = $row['thoigian'];
                                                $trangthai = $row['trangthai'];
                                                if ($trangthai == 1) {
                                                    $kq_tt = '<span style="font-weight: 500;font-family: sans-serif;background-color: aquamarine;padding: 4px;border-radius: 4px;">Đang giao hàng</span>';
                                                } else if ($trangthai == 2) {
                                                    $kq_tt = '<span style="font-weight: 500;font-family: sans-serif;background-color: chartreuse;padding: 4px;border-radius: 4px;">Giao hàng thành công</span>';
                                                } else {
                                                    $kq_tt = '<span style="font-weight: 500;font-family: sans-serif;background-color: gray;padding: 4px;border-radius: 4px;">Giao hàng thất bại</span>';
                                                }

                                                ?>
                                            <tr>
                                                <td class="product-thumbnail" style="width: 5px;"><a><?= $stt ?></a></td>
                                                <td class="product-thumbnail" style="padding: 0 0px; border: 0px solid black;">

                                                    <table>
                                                        <thead>
                                                            <tr>
                                                                <th><span>STT</span></th>
                                                                <th class="product-thumbnail" style="max-width: 111px;">HÌNH ẢNH</th>
                                                                <th class="product-thumbnail" style="width: 700px;">THÔNG TIN CHI TIẾT</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php
                                                            $stt1 = 0;
                                                            for ($i_hang = 0; $i_hang < count($json_hang); $i_hang++) {
                                                                $stt1++;
                                                                $h_masp = $json_hang[$i_hang]['masp'];
                                                                $h_slsp = $json_hang[$i_hang]['soluong'];
                                                                $sl_sp_1 = $sl_sp_1 + $h_slsp;

                                                                $data_sp = $ketnoi->query("SELECT * FROM `san_pham` WHERE `ma_sp` = '" . $h_masp . "'")->fetch_array();

                                                                $masp = $data_sp['ma_sp'];
                                                                $giasp = $data_sp['gia_sp'];
                                                                $ténsp = $data_sp['ten_sp'];

                                                                //$ténsp = sub_name($ténsp, 20) . '...';
                                                                $img = $data_sp['anh_sp'];
                                                                $img = explode(",", $img)[rand(0, 2)];
                                                                $trangthai = $data_sp['trangthai_sp'];
                                                                $tongtien = ($tongtien + $giasp) * $h_slsp;
                                                                ?>
                                                                <tr>
                                                                    <td rowspan="4"><a><?= $stt1 ?></a></td>
                                                                    <td rowspan="4">
                                                                        <a href="../product-details/?masp=<?= $masp ?>"><img src="<?= $img ?>" alt="product images"></a>
                                                                    </td>
                                                                    <td>
                                                                        MÃ: <?= $h_masp ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        TÊN SP: <?= $ténsp ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        GIÁ BÁN: <?= $giasp ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        SỐ LƯỢNG: <?= $h_slsp ?>
                                                                    </td>
                                                                </tr>
                                                            <?php
                                                            }
                                                            $phi_vanchuyen = $sl_sp_1 * 5000;
                                                            ?>
                                                            <tr>
                                                                <td colspan="2" style="font-size: 13px;text-align: left;padding-left: 6px;background-color: #f4ffca;">
                                                                    Phí ship: <span style="background-color: #00ffd2;border-radius: 3px;"><?= tien($phi_ship) ?>đ</span><br>
                                                                    TỔNG ĐƠN HÀNG: <span style="background-color: darkorange;border-radius: 3px;"><?= tien($tong_phi) ?>đ</span><br>
                                                                    Trạng thái đơn hàng: <?= $kq_tt ?>
                                                                </td>
                                                                <td colspan="1" style="text-align: left; padding-left: 30px; background-color: #f4ffca;">
                                                                    Họ tên: <?=$user_kh['hoten']?><br/>
                                                                    Số điện thoại: <?=$user_kh['dienthoai']?><br/>
                                                                    Địa chi: <?=$user_kh['diachi']?><br/>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="3" style="text-align: left; padding-left: 30px; background-color: #f4ffca;">
                                                                    Cập nhật trạng thái đơn hàng:
                                                                    <a href="../don-dat-hang/?tt_madon=<?= $madon ?>_1" style="border: 2px solid #ff8900;padding: 1px 3px;text-align: center;text-decoration: none;display: inline-block;font-size: 12px;margin-left: 20px;">Đang giao hàng</a>
                                                                    <a href="../don-dat-hang/?tt_madon=<?= $madon ?>_2" style="border: 2px solid #04AA6D;padding: 1px 3px;text-align: center;text-decoration: none;display: inline-block;font-size: 12px;margin-left: 20px;">Giao hàng xong</a>
                                                                    <a href="../don-dat-hang/?tt_madon=<?= $madon ?>_3" style="border: 2px solid red;padding: 1px 3px;text-align: center;text-decoration: none;display: inline-block;font-size: 12px;margin-left: 20px;">Hủy đơn</a>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>

                                                </td>
                                            </tr>
                                        <?php
                                            }
                                        }
                                        ?>
                                    </tbody>
                                </table>

                            </div>

                        </div>

                        <!-- Start Pagenation -->
                        <div class="row">
                            <div class="col-xs-12">
                                <ul class="htc__pagenation">
                                    <li><a href="../product-grid/?page=<?= ($_SESSION['_page_dh'] - 1) ?>"><i class="zmdi zmdi-chevron-left"></i></a></li>
                                    <?php
                                    if ($_SESSION['_page_dh'] > 1) {
                                        echo '<li ><a href="../product-grid/?page=' . ($_SESSION['_page_dh'] - 1) . '">' . ($_SESSION['_page_dh'] - 1) . '</a></li>';
                                    }
                                    ?>
                                    <li class="active"><a href="../product-grid/?page=<?= ($_SESSION['_page_dh']) ?>"><?= ($_SESSION['_page_dh']) ?></a></li>
                                    <?php
                                    if ($stt > 3 and $_SESSION['_page_dh'] < ceil($stt / 3)) {
                                        echo '<li ><a href="../product-grid/?page=' . ($_SESSION['_page_dh'] + 1) . '">' . ($_SESSION['_page_dh'] + 1) . '</a></li>';
                                    }
                                    ?>
                                    <?php
                                    if ($_SESSION['_page_dh'] + 1 < ceil($stt / 3)) {
                                    ?>
                                        <li><a href="">...</a></li>
                                        <li><a href="../product-grid/?page=<?= ceil($stt / 3) ?>"><?= ceil($stt / 3) ?></a></li>
                                    <?php } ?>
                                    <li><a href="../product-grid/?page=<?= ($_SESSION['_page_dh'] + 1) ?>"><i class="zmdi zmdi-chevron-right"></i></a></li>
                                </ul>
                            </div>
                        </div><br><br>
                        <!-- End Pagenation -->

                    </div>
                    <!-- cart-main-area end -->
                    <!-- Start Brand Area -->
                    <div class="htc__brand__area bg__cat--4">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="ht__brand__inner">
                                        <ul class="brand__list owl-carousel clearfix">
                                            <li><a href="#"><img src="../images/brand/1.png" alt="brand images"></a></li>
                                            <li><a href="#"><img src="../images/brand/2.png" alt="brand images"></a></li>
                                            <li><a href="#"><img src="../images/brand/3.png" alt="brand images"></a></li>
                                            <li><a href="#"><img src="../images/brand/4.png" alt="brand images"></a></li>
                                            <li><a href="#"><img src="../images/brand/5.png" alt="brand images"></a></li>
                                            <li><a href="#"><img src="../images/brand/5.png" alt="brand images"></a></li>
                                            <li><a href="#"><img src="../images/brand/1.png" alt="brand images"></a></li>
                                            <li><a href="#"><img src="../images/brand/2.png" alt="brand images"></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Brand Area -->
                    <!-- Start Footer Area -->
                    <footer id="htc__footer">
                        <!-- Start Footer Widget -->
                        <div class="footer__container bg__cat--1">
                            <div class="container">
                                <div class="row">
                                    <!-- Start Single Footer Widget -->
                                    <div class="col-md-3 col-sm-6 col-xs-12">
                                        <div class="footer">
                                            <h2 class="title__line--2">Coming Up</h2>
                                            <div class="ft__details">
                                                <p>Lorem ipsum dolor sit amet, consectetur adipisizing elit, sed do eiusmod tempor incididunt utlabore et dolore magna aliqua. Út cưng</p>
                                                <div class="ft__social__link">
                                                    <ul class="social__link">
                                                        <li><a href="#"><i class="icon-social-twitter icons"></i></a></li>

                                                        <li><a href="#"><i class="icon-social-instagram icons"></i></a></li>

                                                        <li><a href="#"><i class="icon-social-facebook icons"></i></a></li>

                                                        <li><a href="#"><i class="icon-social-google icons"></i></a></li>

                                                        <li><a href="#"><i class="icon-social-linkedin icons"></i></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Footer Widget -->
                                    <!-- Start Single Footer Widget -->
                                    <div class="col-md-2 col-sm-6 col-xs-12 xmt-40">
                                        <div class="footer">
                                            <h2 class="title__line--2">Information</h2>
                                            <div class="ft__inner">
                                                <ul class="ft__list">
                                                    <li><a href="#">Về chúng tôi</a></li>
                                                    <li><a href="#">Thông tin giao hàng</a></li>
                                                    <li><a href="#">Chính sách bảo mật</a></li>
                                                    <li><a href="#">Điều khoản & Điều kiện</a></li>
                                                    <li><a href="#">sản xuất</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Footer Widget -->
                                    <!-- Start Single Footer Widget -->
                                    <div class="col-md-2 col-sm-6 col-xs-12 xmt-40 smt-40">
                                        <div class="footer">
                                            <h2 class="title__line--2">tài khoản của tôi</h2>
                                            <div class="ft__inner">
                                                <ul class="ft__list">
                                                    <li><a href="#">Tài khoản của tôi</a></li>
                                                    <li><a href="../cart">Hàng hóa của tôi</a></li>
                                                    <li><a href="#">Đăng nhập</a></li>
                                                    <li><a href="../wishlist">danh sách yêu thích</a></li>
                                                    <li><a href="../checkout">Thanh toán liên tục</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Footer Widget -->
                                    <!-- Start Single Footer Widget -->
                                    <div class="col-md-2 col-sm-6 col-xs-12 xmt-40 smt-40">
                                        <div class="footer">
                                            <h2 class="title__line--2">giao dịch của chúng tôi</h2>
                                            <div class="ft__inner">
                                                <ul class="ft__list">
                                                    <li><a href="#">Tài khoản của tôi</a></li>
                                                    <li><a href="../cart">Hàng hóa của tôi</a></li>
                                                    <li><a href="#">Đăng nhập</a></li>
                                                    <li><a href="../wishlist">danh sách yêu thích</a></li>
                                                    <li><a href="../checkout">Thanh toán liên tục</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Footer Widget -->
                                    <!-- Start Single Footer Widget -->
                                    <div class="col-md-3 col-sm-6 col-xs-12 xmt-40 smt-40">
                                        <div class="footer">
                                            <h2 class="title__line--2">BẢN TIN</h2>
                                            <div class="ft__inner">
                                                <div class="news__input">
                                                    <input type="text" placeholder="Your Mail*">
                                                    <div class="send__btn">
                                                        <a class="fr__btn" href="#">Gửi thư</a>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Footer Widget -->
                                </div>
                            </div>
                        </div>
                        <!-- End Footer Widget -->
                        <!-- Start Copyright Area -->
                        <div class="htc__copyright bg__cat--5">
                            <div class="container">
                                <div class="row">
                                    <div class="col-xs-12">
                                        <div class="copyright__inner">
                                            <p>Copyright© <a href="https://freethemescloud.com/">Chủ đề miễn phí Đám mây</a>2018. Bảo lưu mọi quyền.</p>
                                            <a href="#"><img src="../images/others/shape/paypol.png" alt="payment images"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Copyright Area -->
                    </footer>
                    <!-- End Footer Style -->
                </div>
                <!-- Body main wrapper end -->

                <!-- Placed js at the end of the document so the pages load faster -->

                <!-- jquery latest version -->
                <script src="../js/vendor/jquery-3.2.1.min.js"></script>
                <!-- Bootstrap framework js -->
                <script src="../js/bootstrap.min.js"></script>
                <!-- All js plugins included in this file. -->
                <script src="../js/plugins.js"></script>
                <script src="../js/slick.min.js"></script>
                <script src="../js/owl.carousel.min.js"></script>
                <!-- Waypoints.min.js. -->
                <script src="../js/waypoints.min.js"></script>
                <!-- Main js file that contents all jQuery plugins activation. -->
                <script src="../js/main.js"></script>
                <script>
                    function load_hang(x) {
                        var inputVal = document.getElementById(x).value;
                        window.location = "../checkout/?chinhsua=" + x + "&soluong=" + inputVal;
                    }
                </script>
</body>

</html>