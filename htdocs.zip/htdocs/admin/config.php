<?php
session_start();
define("DATABASE", "shop_tranthuong");
define("USERNAME", "root");
define("PASSWORD", "");
define("LOCALHOST", "localhost");
$ketnoi = mysqli_connect(LOCALHOST, USERNAME, PASSWORD, DATABASE);
$ketnoi->query("set names 'utf8'");
date_default_timezone_set('Asia/Ho_Chi_Minh');
$_SESSION['session_request'] = time();
$time = date('h:i d-m-Y');
$tmanh = $ketnoi;
$chiet_khau_card = "15";
if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];

    $user = $ketnoi->query("SELECT * FROM `users` WHERE `taikhoan` = '$username' ")->fetch_array();

    $userr = $user;

    // if(empty($user['id_user'])) {
    // session_start();
    // session_destroy();
    // header('location: /');
    // }

    // if($user['level'] == "-1") {
    // session_start();
    // session_destroy();
    // header('location: /');
    // }

}


if (isset($_SESSION['username_ad'])) {
    $username = $_SESSION['username_ad'];
    $user_ad = $ketnoi->query("SELECT * FROM `users_admind` WHERE `username` = '$username' ")->fetch_array();
}



$ip = $_SERVER['REMOTE_ADDR'];
if (!empty($_SERVER['WWW_HTTP_CLIENT_IP'])) {
    $ip = $SERVER['WWW_HTTP_CLIENT_IP'];
} else if (!empty($_SERVER['WWW_HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['WWW_HTTP_X-FORWARDED_FOR'];
}
$browser = $_SERVER['HTTP_USER_AGENT'];


function sub_name($ténsp,$leght)
{
    $name2 = '';
    for ($cc = 0; $cc < strlen($ténsp); $cc++) {
        if ($cc > $leght) {
            break;
        }
        $name2 = $name2 . $ténsp[$cc];
    }
    return $name2;
}

function tien($price)
{
    return str_replace(",", ".", number_format($price));
}

function random($string, $int)
{
    return substr(str_shuffle($string), 0, $int);
}

function xuongdong_html($string)
{
    return str_replace("
", "<br>", $string);
}

function xoadau($strTitle)
{
    //$strTitle=strtolower($strTitle);
    $strTitle = trim($strTitle);
    $strTitle = str_replace(' ', '-', $strTitle);
    $strTitle = preg_replace("/(ò|ó|ọ|ỏ|õ|ơ|ờ|ớ|ợ|ở|ỡ|ô|ồ|ố|ộ|ổ|ỗ)/", 'o', $strTitle);
    $strTitle = preg_replace("/(Ò|Ó|Ọ|Ỏ|Õ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ|Ô|Ố|Ổ|Ộ|Ồ|Ỗ)/", 'o', $strTitle);
    $strTitle = preg_replace("/(à|á|ạ|ả|ã|ă|ằ|ắ|ặ|ẳ|ẵ|â|ầ|ấ|ậ|ẩ|ẫ)/", 'a', $strTitle);
    $strTitle = preg_replace("/(À|Á|Ạ|Ả|Ã|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ|Â|Ấ|Ầ|Ậ|Ẩ|Ẫ)/", 'a', $strTitle);
    $strTitle = preg_replace("/(ề|ế|ệ|ể|ê|ễ|é|è|ẻ|ẽ|ẹ)/", 'e', $strTitle);
    $strTitle = preg_replace("/(Ể|Ế|Ệ|Ể|Ê|Ễ|É|È|Ẻ|Ẽ|Ẹ)/", 'e', $strTitle);
    $strTitle = preg_replace("/(ừ|ứ|ự|ử|ư|ữ|ù|ú|ụ|ủ|ũ)/", 'u', $strTitle);
    $strTitle = preg_replace("/(Ừ|Ứ|Ự|Ử|Ư|Ữ|Ù|Ú|Ụ|Ủ|Ũ)/", 'u', $strTitle);
    $strTitle = preg_replace("/(ì|í|ị|ỉ|ĩ)/", 'i', $strTitle);
    $strTitle = preg_replace("/(Ì|Í|Ị|Ỉ|Ĩ)/", 'i', $strTitle);
    $strTitle = preg_replace("/(ỳ|ý|ỵ|ỷ|ỹ)/", 'y', $strTitle);
    $strTitle = preg_replace("/(Ỳ|Ý|Ỵ|Ỷ|Ỹ)/", 'y', $strTitle);
    $strTitle = str_replace('đ', 'd', $strTitle);
    $strTitle = str_replace('Đ', 'd', $strTitle);
    $strTitle = preg_replace("/[^-a-zA-Z0-9]/", '', $strTitle);
    return $strTitle;
}
