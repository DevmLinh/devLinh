<?php
error_reporting(0);
echo "Lỗi kết nối vui lòng để tất cả file vào đúng thư mục htdocs nếu dùng trên xampp và kiểm tra kết nối database ở file admind/config.php";

require_once('./admin/config.php');

header("location: trang-chu");
