<?php
$username = '';
require_once('../admin/config.php');

?>
<style>
    .mobile-menu-area .mean-nav ul {
        height: 585px;
        overflow-y: auto;
    }
</style>
<header id="htc__header" class="htc__header__area header--one">
    <!-- Start Mainmenu Area -->
    <div id="sticky-header-with-topbar" class="mainmenu__wrap sticky__header">
        <div class="container">
            <div class="row">
                <div class="menumenu__container clearfix">
                    <div class="col-lg-2 col-md-2 col-sm-3 col-xs-5">
                        <div class="logo">
                            <a href="../trang-chu"><img src="../images/logo/5.png" alt="logo images"></a>
                        </div>
                    </div>
                    <div class="col-md-7 col-lg-8 col-sm-5 col-xs-3">
                        <nav class="main__menu__nav hidden-xs hidden-sm">
                            <ul class="main__menu">
                                <li class="drop"><a href="../trang-chu">Trang Chủ</a></li>
                                <li class="drop"><a href="../product-grid">Lưới sản phẩm</a></li>
                                </li>
                                <li class="drop"><a>trang</a>
                                    <ul class="dropdown" style="background-color: #d10000;">
                                        <li><a href="../checkout">Giỏ hàng</a></li>
                                        <li><a href="../contact">liên hệ</a></li>
                                        <li><a href="../product-grid">lưới sản phẩm</a></li>
                                        <li><a href="../wishlist">Danh sách yêu thích</a></li>
                                    </ul>
                                </li>
                                <li><a href="../contact">liên hệ</a></li>
                            </ul>
                        </nav>

                        <div class="mobile-menu clearfix visible-xs visible-sm">
                            <nav id="mobile_dropdown">
                                <ul style="background-color: #d10000;">
                                    <li><a href="../trang-chu">Trang Chủ</a></li>
                                    <li><a href="../checkout">Giỏ hàng</a></li>
                                    <li><a href="../product-grid">lưới sản phẩm</a></li>
                                    <li><a href="../wishlist">Danh sách yêu thích</a></li>

                                    <li><a href="../contact">liên hệ</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <div class="col-md-3 col-lg-2 col-sm-4 col-xs-4">
                        <div class="header__right">
                            <div class="header__search search search__open">
                                <i class="icon-magnifier icons"></i>
                            </div>
                            <div class="header__account">
                                <ul class="main__menu">
                                    <li class="drop"><i class="icon-user icons"></i>
                                        <ul class="dropdown">
                                            <?php if (isset($_SESSION['username'])) { ?>
                                                <li><a href="../profile"><?= $_SESSION['username'] ?></a></li>
                                                <li><a href="../dang-xuat">ĐĂNG XUẤT</a></li>
                                            <?php } else { ?>
                                                <li><a href="../dang-nhap">ĐĂNG NHẬP</a></li>
                                                <li><a href="../dang-ky">ĐĂNG KÝ</a></li>
                                            <?php } ?>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                            <div class="htc__shopping__cart">
                                <a class="cart__menu"><i class="icon-handbag icons"></i></a>
                                <a><span class="htc__qua cart__menu"><?= count($_SESSION['arrgiohang']) ?></span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mobile-menu-area"></div>
        </div>
    </div>
    <!-- End Mainmenu Area -->
</header>

<div class="body__overlay"></div>
<!-- Start Offset Wrapper -->
<div class="offset__wrapper">
    <!-- Start Search Popap -->
    <div class="search__area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="search__inner">
                        <form action="#" method="get">
                            <input placeholder="Search here... " type="text">
                            <button type="submit"></button>
                        </form>
                        <div class="search__close__btn">
                            <span class="search__close__btn_icon"><i class="zmdi zmdi-close"></i></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Search Popap -->
    <!-- Start Cart Panel -->
    <div class="shopping__cart">

        <div class="shopping__cart__inner">
            <div class="offsetmenu__close__btn">
                <a><i class="zmdi zmdi-close"></i></a>
            </div>
            <div class="shp__cart__wrap">
                <?php
                if (isset($_SESSION['arrgiohang'])) {
                    $tongtien = 0;
                    for ($hh = 0; $hh < count($_SESSION['arrgiohang']); $hh++) {
                        $masp = $_SESSION['arrgiohang'][$hh]["masp"];
                        $sl_sp = $_SESSION['arrgiohang'][$hh]["soluong"];

                        $data_sp = $ketnoi->query("SELECT * FROM `san_pham` WHERE `ma_sp` = '" . $masp . "'")->fetch_array();

                        $masp = $data_sp['ma_sp'];
                        $giasp = $data_sp['gia_sp'];
                        $ténsp = $data_sp['ten_sp'];

                        //$ténsp = sub_name($ténsp, 20) . '...';
                        $img = $data_sp['anh_sp'];
                        $img = explode(",", $img)[rand(0, 2)];
                        $trangthai = $data_sp['trangthai_sp'];

                        $tongtien = ($tongtien + $giasp) * $sl_sp;
                ?>

                        <div class="shp__single__product">
                            <div class="shp__pro__thumb">
                                <a>
                                    <img src="<?=$img?>" alt="product images">
                                </a>
                            </div>
                            <div class="shp__pro__details">
                                <h2><a href="../product-details/?masp=<?= $masp ?>"><?= $ténsp ?></a></h2>
                                <span class="quantity">Số lượng: <?= $sl_sp ?></span>
                                <span class="shp__price"><?=tien($giasp)."đ"?></span>
                            </div>
                            <div class="remove__btn">
                                <a href="../product-grid/?xoagiohang=<?= $hh ?>" title="Remove this item"><i class="zmdi zmdi-close"></i></a>
                            </div>
                        </div>
                <?php
                    }
                }
                ?>
            </div>
            <ul class="shoping__total">
                <li class="subtotal">Tổng đơn hàng:</li>
                <li class="total__price"><?=tien($tongtien)."đ"?></li>
            </ul>
            <ul class="shopping__btn">
                <li class="shp__checkout"><a href="../checkout">THANH TOÁN</a></li>
            </ul>
            <br><br><br>
        </div>
    </div>
    <!-- End Cart Panel -->
</div>
<!-- End Offset Wrapper -->