<?php
require_once('../admin/config.php');

if (!isset($_SESSION['arrgiohang']) or !isset($_SESSION['arrgiohang1'])) {
    $_SESSION['arrgiohang'] = [];
    $_SESSION['arrgiohang1'] = [];
}

if (isset($_GET['themgiohang'])) {
    $data_sp = $ketnoi->query("SELECT * FROM `san_pham` WHERE `ma_sp` = '" . $_GET['themgiohang'] . "'")->fetch_array();
    if ($data_sp['id_sp'] != '') {
        $ma_sp = $_GET['themgiohang'];
        $ten_sp = $data_sp['ten_sp'];
        $sl_sp  = $data_sp['soluong_sp'];
        $gia_sp = $data_sp['gia_sp'];
        $trangthai_sp = $data_sp['trangthai_sp'];

        if (in_array($_GET['themgiohang'], $_SESSION['arrgiohang1'])) {
            for ($cc = 0; $cc < count($_SESSION['arrgiohang']); $cc++) {
                if ($_SESSION['arrgiohang'][$cc]["masp"] == $ma_sp) {
                    $soluong_spht = $_SESSION['arrgiohang'][$cc]["soluong"];
                    $soluong_spht = $soluong_spht + 1;
                    $_SESSION['arrgiohang'][$cc]["soluong"] = $soluong_spht;
                    echo "<script>confirm('Bạn đã thêm [" . $soluong_spht . "] [ " . $ten_sp . " ] vào giỏ hàng.');</script>";
                    break;
                }
            }
        } else {


            array_push($_SESSION['arrgiohang'], array("masp" => $_GET['themgiohang'], "soluong" => "1"));
            array_push($_SESSION['arrgiohang1'], $_GET['themgiohang']);
            echo "<script>confirm('Bạn đã thêm [ " . $ten_sp . " ] vào giỏ hàng.');</script>";
        }
    } else {
        echo "<script>confirm('Mã sản phẩm [ " . $_GET['themgiohang'] . " ] không tồn tại.');</script>";
    }
    echo '<meta http-equiv="refresh" content="0;url=../product-grid">';
}

if (isset($_GET['xoagiohang'])) {
    $xoa = $_GET['xoagiohang'];

    $data_sp = $ketnoi->query("SELECT * FROM `san_pham` WHERE `ma_sp` = '" . $_SESSION['arrgiohang1'][$xoa] . "'")->fetch_array();
    $ten_sp = $data_sp['ten_sp'];

    array_splice($_SESSION['arrgiohang'], $xoa, 1);
    array_splice($_SESSION['arrgiohang1'], $xoa, 1);
    echo "<script>confirm('Bạn đã xóa [ " . $ten_sp . " ] ra khỏi giỏ hàng giỏ hàng.');</script>";
    echo '<meta http-equiv="refresh" content="0;url=../product-grid">';
}



if (!isset($_SESSION['_page_sp'])) {
    $_SESSION['_page_sp'] = '1';
}

if (isset($_GET['page'])) {
    $_SESSION['_page_sp'] = $_GET['page'];
}



$chon1 = '';
$chon2 = '';
$chon3 = '';
$chon4 = '';
$chon5 = '';

if (!isset($_SESSION['sapxep'])) {
    $_SESSION['sapxep'] = '`san_pham`.`ngay_sp` DESC';
}
if (isset($_POST['sapxep'])) {
    $sapxep = $_POST['sapxep'];
    if ($sapxep == 1) {
        $chon1 = 'selected';
        $_SESSION['sapxep'] = '`san_pham`.`ngay_sp` DESC';
    } elseif ($sapxep == 2) {
        $chon2 = 'selected';
        $_SESSION['sapxep'] = '`san_pham`.`gia_sp` ASC';
    } elseif ($sapxep == 3) {
        $chon3 = 'selected';
        $_SESSION['sapxep'] = '`san_pham`.`gia_sp` DESC';
    } elseif ($sapxep == 4) {
        $chon4 = 'selected';
        $_SESSION['sapxep'] = '`san_pham`.`sl_yeuthich` DESC';
    } elseif ($sapxep == 5) {
        $chon5 = 'selected';
        $_SESSION['sapxep'] = '`san_pham`.`daban_sp` DESC';
    }
}

$gialoc_goc = '';
$sql_loc_gia = "";
if (isset($_POST['gialoc'])) {
    $gialoc_goc = $_POST['gialoc'];
    $gialoc = str_replace("đ", "", $_POST['gialoc']);
    $gialoc = str_replace(" ", "", $gialoc);
    $gia_min = explode('-', $gialoc)[0];
    $gia_max = explode('-', $gialoc)[1];

    $sql_loc_gia = " WHERE san_pham.gia_sp >= " . $gia_min . " and san_pham.gia_sp <= " . $gia_max;
}









?>


<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Lưới Sản Phẩm || Asbab - Mẫu HTML5 thương mại điện tử</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Place favicon.ico in the root directory -->
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">


    <!-- All css files are included here. -->
    <!-- Bootstrap fremwork main css -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- Owl Carousel min css -->
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">
    <!-- This core.css file contents all plugings css file. -->
    <link rel="stylesheet" href="../css/core.css">
    <!-- Theme shortcodes/elements style -->
    <link rel="stylesheet" href="../css/shortcode/shortcodes.css">
    <!-- Theme main style -->
    <link rel="stylesheet" href="../style.css">
    <!-- Responsive css -->
    <link rel="stylesheet" href="../css/responsive.css">
    <!-- User style -->
    <link rel="stylesheet" href="../css/custom.css">


    <!-- Modernizr JS -->
    <script src="../js/vendor/modernizr-3.5.0.min.js"></script>
</head>

<body>
    <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>error time</strong> browser. Please <a href="http://browsehappy.com/">nâng cấp trình duyệt của bạn</a>để cải thiện trải nghiệm của bạn.</p>
    <![endif]-->

    <!-- Body main wrapper start -->
    <div class="wrapper">
        <!-- Start Header Style -->
        <?php require_once('../pages/topmenu-header.php'); ?>
        <!-- End Header Area -->

        <!-- End Offset Wrapper -->
        <!-- Start Bradcaump area -->
        <div class="ht__bradcaump__area" style="background: rgba(0, 0, 0, 0) url(images/bg/5.jpg) no-repeat scroll center center / cover ;">
            <div class="ht__bradcaump__wrap">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="bradcaump__inner">
                                <nav class="bradcaump-inner">
                                    <a class="breadcrumb-item" href="../trang-chu">Trang Chủ</a>
                                    <span class="brd-separetor"><i class="zmdi zmdi-chevron-right"></i></span>
                                    <span class="breadcrumb-item active">Các sản phẩm</span>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Bradcaump area -->
        <!-- Start Product Grid -->
        <section class="htc__product__grid bg__white ptb--100">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9 col-lg-push-3 col-md-9 col-md-push-3 col-sm-12 col-xs-12">
                        <div class="htc__product__rightidebar">
                            <div class="htc__grid__top">
                                <div class="ht__pro__qun">
                                    <?php
                                    $tongsp = mysqli_num_rows(mysqli_query($ketnoi, "SELECT * FROM san_pham"));
                                    $den = ($_SESSION['_page_sp'] * 9);
                                    if ($den > $tongsp) {
                                        $den = $tongsp;
                                    }
                                    ?>

                                    <span>Đang hiển thị <?= ($_SESSION['_page_sp'] * 9 - (($_SESSION['_page_sp'] + 9) - 2)) ?>-<?= $den ?> của <?= $tongsp ?> sản phẩm</span>
                                </div>
                                <!-- Start List And Grid View -->
                                <ul class="view__mode" role="tablist">
                                    <li role="presentation" class="grid-view active"><a href="#grid-view" role="tab" data-toggle="tab"><i class="zmdi zmdi-grid"></i></a></li>
                                    <li role="presentation" class="list-view"><a href="#list-view" role="tab" data-toggle="tab"><i class="zmdi zmdi-view-list"></i></a></li>
                                </ul>
                                <!-- End List And Grid View -->
                            </div>
                            <!-- Start Product View -->
                            <div class="row">
                                <div class="shop__grid__view__wrap">
                                    <div role="tabpanel" id="grid-view" class="single-grid-view tab-pane fade in active clearfix">
                                        <?php

                                        $dau_page = ($_SESSION['_page_sp'] * 9) - 9;
                                        $query_sp = $ketnoi->query("SELECT * FROM `san_pham`" . $sql_loc_gia . " ORDER BY " . $_SESSION['sapxep'] . "");
                                        $stt = 0;
                                        while ($row = mysqli_fetch_array($query_sp)) {
                                            $stt++;
                                            if ($stt >= $dau_page and $stt <= $dau_page + 9) {
                                                $masp = $row['ma_sp'];
                                                $giasp = $row['gia_sp'];
                                                $ténsp = $row['ten_sp'];

                                                $ténsp = sub_name($ténsp, 20) . '...';
                                                $img = $row['anh_sp'];
                                                $img = explode(",", $img)[rand(0, 2)];
                                                $trangthai = $row['trangthai_sp'];
                                                $hienthi = "Hiển thị";
                                                if ($trangthai == 1) {

                                                    //$check_hh = mysqli_num_rows(mysqli_query($ketnoi, "SELECT * FROM yeu_thich WHERE taikhoan ='".$_SESSION['username']."' and `ma_sp` = '".$masp."'"));

                                        ?>
                                                    <!-- Start Single Product -->
                                                    <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12" style="width: 245px;height: 411.69px;">
                                                        <div class="category">
                                                            <div class="ht__cat__thumb" style="min-width: 205px;min-height: 300px;">
                                                                <a href="../product-details/?masp=<?= $masp ?>">
                                                                    <img src="<?= $img ?>" alt="product images">
                                                                </a>
                                                            </div>
                                                            <div class="fr__hover__info">
                                                                <ul class="product__action">
                                                                    <!--li><a href="../wishlist"><i class="icon-heart icons"></i></a></li-->
                                                                    <li onclick="themyeuthich('<?= $masp ?>')"><a><i class="icon-heart icons"></i></a></li>

                                                                    <li onclick="themvaogiohang('<?= $masp ?>')"><a><i class="icon-handbag icons"></a></i></li>


                                                                </ul>
                                                            </div>
                                                            <div class="fr__product__inner">
                                                                <h4><a href="../product-details/?masp=<?= $masp ?>"><?= $ténsp ?></a></h4>
                                                                <ul class="fr__pro__prize">
                                                                    <li class="old__prize"><del><?= tien($giasp + 45000) ?></del>đ</li>
                                                                    <li><?= tien($giasp) ?>đ</li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- End Single Product -->
                                        <?php
                                                }
                                            }
                                        }
                                        ?>

                                    </div>
                                    <div role="tabpanel" id="list-view" class="single-grid-view tab-pane fade clearfix">
                                        <div class="col-xs-12">
                                            <div class="ht__list__wrap">
                                                <?php

                                                $dau_page = ($_SESSION['_page_sp'] * 9) - 9;
                                                $query_sp = $ketnoi->query("SELECT * FROM `san_pham`" . $sql_loc_gia . " ORDER BY " . $_SESSION['sapxep'] . "");
                                                $stt = 0;
                                                while ($row = mysqli_fetch_array($query_sp)) {
                                                    $stt++;
                                                    if ($stt >= $dau_page and $stt <= $dau_page + 9) {
                                                        $giasp = $row['gia_sp'];
                                                        $ténsp = $row['ten_sp'];

                                                        $ténsp = sub_name($ténsp, 20) . '...';
                                                        $img = $row['anh_sp'];
                                                        $img = explode(",", $img)[rand(0, 2)];
                                                        $trangthai = $row['trangthai_sp'];
                                                        $hienthi = "Hiển thị";
                                                        if ($trangthai == 1) {
                                                ?>
                                                            <!-- Start List Product -->
                                                            <div class="ht__list__product">
                                                                <div class="ht__list__thumb">
                                                                    <a href="../product-details/?masp=<?= $masp ?>"><img src="<?= $img ?>" alt="product images"></a>
                                                                </div>
                                                                <div class="htc__list__details">
                                                                    <h2><a href="../product-details/?masp=<?= $masp ?>"><?= $ténsp ?></a></h2>
                                                                    <ul class="pro__prize">
                                                                        <li class="old__prize"><del><?= tien($giasp + 45000) ?></del>đ</li>
                                                                        <li><?= tien($giasp) ?>đ</li>
                                                                    </ul>
                                                                    <!--ul class="rating">
                                                                        <li><i class="icon-star icons"></i></li>
                                                                        <li><i class="icon-star icons"></i></li>
                                                                        <li><i class="icon-star icons"></i></li>
                                                                        <li class="old"><i class="icon-star icons"></i></li>
                                                                        <li class="old"><i class="icon-star icons"></i></li>
                                                                    </ul-->
                                                                    <!--p>Lorem ipsum dolor sit amet, consectetur adipisLorem ipsum dolor sit amet, consec adipisizing elit, sed do eiusmod tempor incididunt utlabore et dolore magna aliqul Ut enim ad minim veniam, quis nostrud exexec ullamcolaboris nisi ut aliquip ex ea commododo dosequat.</p-->
                                                                    <div class="fr__list__btn">
                                                                        <a class="fr__btn" href="../cart">Thêm vào giỏ hàng</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- End List Product -->
                                                <?php
                                                        }
                                                    }
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Product View -->
                        </div>
                        <!-- Start Pagenation -->
                        <div class="row">
                            <div class="col-xs-12">
                                <ul class="htc__pagenation">
                                    <li><a href="../product-grid/?page=<?= ($_SESSION['_page_sp'] - 1) ?>"><i class="zmdi zmdi-chevron-left"></i></a></li>
                                    <?php
                                    if ($_SESSION['_page_sp'] > 1) {
                                        echo '<li ><a href="../product-grid/?page=' . ($_SESSION['_page_sp'] - 1) . '">' . ($_SESSION['_page_sp'] - 1) . '</a></li>';
                                    }
                                    ?>
                                    <li class="active"><a href="../product-grid/?page=<?= ($_SESSION['_page_sp']) ?>"><?= ($_SESSION['_page_sp']) ?></a></li>
                                    <?php
                                    if ($stt > 9 and $_SESSION['_page_sp'] < ceil($stt / 9)) {
                                        echo '<li ><a href="../product-grid/?page=' . ($_SESSION['_page_sp'] + 1) . '">' . ($_SESSION['_page_sp'] + 1) . '</a></li>';
                                    }
                                    ?>
                                    <?php
                                    if ($_SESSION['_page_sp'] + 1 < ceil($stt / 9)) {
                                    ?>
                                        <li><a href="">...</a></li>
                                        <li><a href="../product-grid/?page=<?= ceil($stt / 9) ?>"><?= ceil($stt / 9) ?></a></li>
                                    <?php } ?>
                                    <li><a href="../product-grid/?page=<?= ($_SESSION['_page_sp'] + 1) ?>"><i class="zmdi zmdi-chevron-right"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <!-- End Pagenation -->
                    </div>
                    <div class="col-lg-3 col-lg-pull-9 col-md-3 col-md-pull-9 col-sm-12 col-xs-12 smt-40 xmt-40">
                        <div class="htc__product__leftsidebar">
                            <!-- Start Prize Range -->
                            <div class="htc-grid-range">
                                <h4 class="title__line--4">Giá bán</h4>
                                <div class="content-shopby">
                                    <div class="price_filter s-filter clear">
                                        <form action="" method="POST">
                                            <div class="htc__select__option">
                                                <select class="ht__select" name="sapxep">
                                                    <option value="1" <?= $chon1 ?>>Sắp xếp mặc định</option>
                                                    <option value="2" <?= $chon2 ?>>Sắp xếp theo giá thấp - cao</option>
                                                    <option value="3" <?= $chon3 ?>>Sắp xếp theo giá cao - thấp</option>
                                                    <option value="4" <?= $chon4 ?>>Sắp xếp theo top yêu thích</option>
                                                    <option value="5" <?= $chon5 ?>>Sắp xếp theo top bán chạy</option>
                                                </select>
                                            </div><br><br>
                                            <div id="slider-range"></div>
                                            <div class="slider__range--output">
                                                <div class="price__output--wrap">
                                                    <div class="price--output">
                                                        <span>Giá bán :</span><input type="text" id="amount" readonly name="gialoc">

                                                    </div>
                                                </div>
                                            </div><br>
                                            <div class="price--filter">
                                                <a href="#"><input type="submit" name="post_loc" value="lọc" style="background: #333333;border: none;width: 100px;" /></a>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- End Best Sell Area -->
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Product Grid -->
        <!-- Start Brand Area -->
        <div class="htc__brand__area bg__cat--4">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="ht__brand__inner">
                            <ul class="brand__list owl-carousel clearfix">
                                <li><a href="#"><img src="../images/brand/1.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/2.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/3.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/4.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/5.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/5.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/1.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/2.png" alt="brand images"></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Brand Area -->
        <!-- Start Banner Area -->
        <div class="htc__banner__area">
            <ul class="banner__list owl-carousel owl-theme clearfix">
                <li><a href="../product-details/?masp=<?= $masp ?>"><img src="../images/banner/bn-3/1.jpg" alt="banner images"></a></li>
                <li><a href="../product-details/?masp=<?= $masp ?>"><img src="../images/banner/bn-3/2.jpg" alt="banner images"></a></li>
                <li><a href="../product-details/?masp=<?= $masp ?>"><img src="../images/banner/bn-3/3.jpg" alt="banner images"></a></li>
                <li><a href="../product-details/?masp=<?= $masp ?>"><img src="../images/banner/bn-3/4.jpg" alt="banner images"></a></li>
                <li><a href="../product-details/?masp=<?= $masp ?>"><img src="../images/banner/bn-3/5.jpg" alt="banner images"></a></li>
                <li><a href="../product-details/?masp=<?= $masp ?>"><img src="../images/banner/bn-3/6.jpg" alt="banner images"></a></li>
                <li><a href="../product-details/?masp=<?= $masp ?>"><img src="../images/banner/bn-3/1.jpg" alt="banner images"></a></li>
                <li><a href="../product-details/?masp=<?= $masp ?>"><img src="../images/banner/bn-3/2.jpg" alt="banner images"></a></li>
            </ul>
        </div>
        <!-- End Banner Area -->
        <!-- End Banner Area -->
        <!-- Start Footer Area -->
        <footer id="htc__footer">
            <!-- Start Footer Widget -->
            <div class="footer__container bg__cat--1">
                <div class="container">
                    <div class="row">
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-3 col-sm-6 col-xs-12">
                            <div class="footer">
                                <h2 class="title__line--2">Coming Up</h2>
                                <div class="ft__details">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisizing elit, sed do eiusmod tempor incididunt utlabore et dolore magna aliqua. Út cưng</p>
                                    <div class="ft__social__link">
                                        <ul class="social__link">
                                            <li><a href="#"><i class="icon-social-twitter icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-instagram icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-facebook icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-google icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-linkedin icons"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40">
                            <div class="footer">
                                <h2 class="title__line--2">Information</h2>
                                <div class="ft__inner">
                                    <ul class="ft__list">
                                        <li><a href="#">Về chúng tôi</a></li>
                                        <li><a href="#">Thông tin giao hàng</a></li>
                                        <li><a href="#">Chính sách bảo mật</a></li>
                                        <li><a href="#">Điều khoản & Điều kiện</a></li>
                                        <li><a href="#">sản xuất</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40 smt-40">
                            <div class="footer">
                                <h2 class="title__line--2">tài khoản của tôi</h2>
                                <div class="ft__inner">
                                    <ul class="ft__list">
                                        <li><a href="#">Tài khoản của tôi</a></li>
                                        <li><a href="../cart">Hàng hóa của tôi</a></li>
                                        <li><a href="#">Đăng nhập</a></li>
                                        <li><a href="../wishlist">danh sách yêu thích</a></li>
                                        <li><a href="../checkout">Thanh toán liên tục</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40 smt-40">
                            <div class="footer">
                                <h2 class="title__line--2">giao dịch của chúng tôi</h2>
                                <div class="ft__inner">
                                    <ul class="ft__list">
                                        <li><a href="#">Tài khoản của tôi</a></li>
                                        <li><a href="../cart">Hàng hóa của tôi</a></li>
                                        <li><a href="#">Đăng nhập</a></li>
                                        <li><a href="../wishlist">danh sách yêu thích</a></li>
                                        <li><a href="../checkout">Thanh toán liên tục</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-3 col-sm-6 col-xs-12 xmt-40 smt-40">
                            <div class="footer">
                                <h2 class="title__line--2">BẢN TIN</h2>
                                <div class="ft__inner">
                                    <div class="news__input">
                                        <input type="text" placeholder="Your Mail*">
                                        <div class="send__btn">
                                            <a class="fr__btn" href="#">Gửi thư</a>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                    </div>
                </div>
            </div>
            <!-- End Footer Widget -->
            <!-- Start Copyright Area -->
            <div class="htc__copyright bg__cat--5">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="copyright__inner">
                                <p>Copyright© <a href="https://freethemescloud.com/">Chủ đề miễn phí Đám mây</a>2018. Bảo lưu mọi quyền.</p>
                                <a href="#"><img src="../images/others/shape/paypol.png" alt="payment images"></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Copyright Area -->
        </footer>
        <!-- End Footer Style -->
    </div>
    <!-- Body main wrapper end -->

    <!-- Placed js at the end of the document so the pages load faster -->
    <!-- jquery latest version -->
    <script src="../js/vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap framework js -->
    <script src="../js/bootstrap.min.js"></script>
    <!-- All js plugins included in this file. -->
    <script src="../js/plugins.js"></script>
    <script src="../js/slick.min.js"></script>
    <script src="../js/owl.carousel.min.js"></script>
    <!-- Waypoints.min.js. -->
    <script src="../js/waypoints.min.js"></script>
    <!-- Main js file that contents all jQuery plugins activation. -->
    <script src="../js/main.js"></script>
    <?php
    if ($gialoc_goc != '') {
    ?>
        <script>
            document.getElementById("amount").value = "<?= $gialoc_goc ?>";
        </script>
    <?php
    }
    ?>
    <script>
        function themvaogiohang(x) {
            window.location = "../product-grid/?themgiohang=" + x;
            // get('../product-grid/', {
            //     themgiohang: x
            // })
            // .then(response => {
            //     // Do something with response.
            // });
        }

        function themyeuthich(x) {
            if (<?= isset($_SESSION['username']) ? "1" : "0" ?> == 0) {
                confirm('Bạn phải đăng nhập để thực hiện thao tác này.');
                window.location = "../dang-nhap";
            } else {
                confirm('Đã thêm [' + x + '] vào danh sách yêu thích.');
                $.get("../trang-chu/?yeuthich=" + x);
            }
        }
    </script>
</body>

</html>