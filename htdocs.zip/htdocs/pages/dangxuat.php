<?php
    include '../admin/config.php';
    unset($_SESSION['username']);
    session_destroy();
    mysqli_close($ketnoi);
    header('location: ../dang-nhap');

?>