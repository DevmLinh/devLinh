<?php







require_once('../admin/config.php');
if(!isset($_SESSION['username'])){
    header("location: trang-chu");
}


$user = $userr['taikhoan'];

$cpass = "";
$npass  = "";
$rnpass = "";
$email = $userr['email'];
$name  = $userr['hoten'];
$sdt   = $userr['dienthoai'];

$erorr['mk']  = "";
$erorr['sdt'] = "";

if (isset($_POST['capnhat'])) {
    $cpass = xoadau(addslashes(strip_tags($_POST['cpassword'])));
    $npass = xoadau(addslashes(strip_tags($_POST['npassword'])));
    $rnpass = xoadau(addslashes(strip_tags($_POST['rnpassword'])));
    $sdt = xoadau(addslashes(strip_tags($_POST['phone'])));

    if ($npass != '') {
        if(strlen($cpass) < 5 or $cpass != $userr['matkhau']){
            echo "<script>confirm('Mật khẩu cũ sai.');</script>";
            $erorr['mk']  = 1;
        }elseif ((strlen($npass) < 5 or $npass != $_POST['rnpassword'])) {
            echo "<script>confirm('Mật khẩu mới độ dài phải lớn hơn 5, không dùng ký tự đặc biệt và mật khẩu nhập lại phải trùng với mật khẩu mới.');</script>";
            $erorr['mk']  = 1;
        }
    }

    if($sdt != ''){
        if ((strpos("_" . $sdt . "_", 0) == false and strlen($sdt) < 8)  and $sdt == $userr['dienthoai']) {
            echo "<script>confirm('Số điện thoại không hợp lệ.');</script>";
            $erorr['sdt'] = 1;
        } else {
            $sdt = '';
        }
    }

    $update_mk = '';
    if ($erorr['mk'] == '') {
        $update_mk = "`matkhau` = '".$npass."'";
    }
    if ($erorr['sdt'] == '') {
        $update_sdt = "`dienthoai` = '".$sdt."'";
    }
    $daup = '';
    if ($erorr['mk'] == '' and $erorr['sdt'] == "") {
        $daup = ",";
    }

    if ($erorr['mk'] == '' or $erorr['sdt'] == "") {
        $sql_update = "UPDATE `users` SET " . $update_mk . $daup . $update_sdt . " WHERE `taikhoan` = '" . $user . "'";
        $update = $ketnoi->query($sql_update);
        if ($update) {
            echo "<script>confirm('Cập nhật thành công.');</script>";
            echo '<meta http-equiv="refresh" content="1;url=../profile">';
        } else {
            echo "<script>confirm('Cập nhật thất bại.');</script>";
        }
    }

}



?>


<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Danh sách yêu thích || Asbab - Mẫu HTML5 thương mại điện tử</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Place favicon.ico in the root directory -->
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    

    <!-- All css files are included here. -->
    <!-- Bootstrap fremwork main css -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- Owl Carousel min css -->
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">
    <!-- This core.css file contents all plugings css file. -->
    <link rel="stylesheet" href="../css/core.css">
    <!-- Theme shortcodes/elements style -->
    <link rel="stylesheet" href="../css/shortcode/shortcodes.css">
    <!-- Theme main style -->
    <link rel="stylesheet" href="../style.css">
    <!-- Responsive css -->
    <link rel="stylesheet" href="../css/responsive.css">
    <!-- User style -->
    <link rel="stylesheet" href="../css/custom.css">


    <!-- Modernizr JS -->
    <script src="../js/vendor/modernizr-3.5.0.min.js"></script>
</head>

<body>
    <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>error time</strong> browser. Please <a href="http://browsehappy.com/">nâng cấp trình duyệt của bạn</a>để cải thiện trải nghiệm của bạn.</p>
    <![endif]-->  

    <!-- Body main wrapper start -->
    <div class="wrapper">
        <!-- Start Header Style -->
        <?php require_once('../pages/topmenu-header.php');?>
        <!-- End Header Area -->

        