<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>The row || Asbab - Mẫu HTML5 thương mại điện tử</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Place favicon.ico in the root directory -->
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    

    <!-- All css files are included here. -->
    <!-- Bootstrap fremwork main css -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- Owl Carousel min css -->
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">
    <!-- This core.css file contents all plugings css file. -->
    <link rel="stylesheet" href="../css/core.css">
    <!-- Theme shortcodes/elements style -->
    <link rel="stylesheet" href="../css/shortcode/shortcodes.css">
    <!-- Theme main style -->
    <link rel="stylesheet" href="../style.css">
    <!-- Responsive css -->
    <link rel="stylesheet" href="../css/responsive.css">
    <!-- User style -->
    <link rel="stylesheet" href="../css/custom.css">


    <!-- Modernizr JS -->
    <script src="../js/vendor/modernizr-3.5.0.min.js"></script>
</head>

<body>
    <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>error time</strong> browser. Please <a href="http://browsehappy.com/">nâng cấp trình duyệt của bạn</a>để cải thiện trải nghiệm của bạn.</p>
    <![endif]-->  

    <!-- Body main wrapper start -->
    <div class="wrapper">
        <!-- Start Header Style -->
        <?php require_once('../pages/topmenu-header.php');?>
        <!-- End Header Area -->

        
        <!-- End Bradcaump area -->
        <!-- cart-main-area start -->
        <div class="cart-main-area ptb--100 bg__white">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <form action="#">               
                            <div class="table-content table-responsive">
                                <table>
                                    <thead>
                                        <tr>
                                            <th class="product-thumbnail">sản phẩm của tôi</th>
                                            <th class="product-name">tên sản phẩm</th>
                                            <th class="product-price">Giá bán</th>
                                            <th class="product-quantity">Định lượng</th>
                                            <th class="product-subtotal">Total cộng</th>
                                            <th class="product-remove">Gỡ bỏ</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td class="product-thumbnail"><a href="#"><img src="../images/product-2/cart-img/1.jpg" alt="product img" /></a></td>
                                            <td class="product-name"><a href="#">Trang phục mới cho ngày chủ nhật</a>
                                                <ul  class="pro__prize">
                                                    <li class="old__prize">$82,5</li>
                                                    <li>$75,2</li>
                                                </ul>
                                            </td>
                                            <td class="product-price"><span class="amount">£165,00</span></td>
                                            <td class="product-quantity"><input type="number" value="1" /></td>
                                            <td class="product-subtotal">£165,00</td>
                                            <td class="product-remove"><a href="#"><i class="icon-trash icons"></i></a></td>
                                        </tr>
                                        <tr>
                                            <td class="product-thumbnail"><a href="#"><img src="../images/product-2/cart-img/2.jpg" alt="product img" /></a></td>
                                            <td class="product-name"><a href="#">Trang phục mới cho ngày chủ nhật</a>
                                                <ul  class="pro__prize">
                                                    <li class="old__prize">$82,5</li>
                                                    <li>$75,2</li>
                                                </ul>
                                            </td>
                                            <td class="product-price"><span class="amount">£50,00</span></td>
                                            <td class="product-quantity"><input type="number" value="1" /></td>
                                            <td class="product-subtotal">£50,00</td>
                                            <td class="product-remove"><a href="#"><i class="icon-trash icons"></i></a></td>
                                        </tr>
                                        <tr>
                                            <td class="product-thumbnail"><a href="#"><img src="../images/product-2/cart-img/3.jpg" alt="product img" /></a></td>
                                            <td class="product-name"><a href="#">Trang phục mới cho ngày chủ nhật</a>
                                                <ul  class="pro__prize">
                                                    <li class="old__prize">$82,5</li>
                                                    <li>$75,2</li>
                                                </ul>
                                            </td>
                                            <td class="product-price"><span class="amount">£50,00</span></td>
                                            <td class="product-quantity"><input type="number" value="1" /></td>
                                            <td class="product-subtotal">£50,00</td>
                                            <td class="product-remove"><a href="#"><i class="icon-trash icons"></i></a></td>
                                        </tr>
                                        <tr>
                                            <td class="product-thumbnail"><a href="#"><img src="../images/product-2/cart-img/4.jpg" alt="product img" /></a></td>
                                            <td class="product-name"><a href="#">Trang phục mới cho ngày chủ nhật</a>
                                                <ul  class="pro__prize">
                                                    <li class="old__prize">$82,5</li>
                                                    <li>$75,2</li>
                                                </ul>
                                            </td>
                                            <td class="product-price"><span class="amount">£50,00</span></td>
                                            <td class="product-quantity"><input type="number" value="1" /></td>
                                            <td class="product-subtotal">£50,00</td>
                                            <td class="product-remove"><a href="#"><i class="icon-trash icons"></i></a></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="row">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="buttons-cart--inner">
                                        <div class="buttons-cart">
                                            <a href="#">Tiếp tục mua sắm</a>
                                        </div>
                                        <div class="buttons-cart checkout--btn">
                                            <a href="#">cập nhật</a>
                                            <a href="#">Thanh toán liên tục</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-sm-12 col-xs-12">
                                    <div class="ht__coupon__code">
                                        <span>nhập mã giảm giá của bạn</span>
                                        <div class="coupon__box">
                                            <input type="text" placeholder="">
                                            <div class="ht__cp__btn">
                                                <a href="#">go to</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-12 col-xs-12 smt-40 xmt-40">
                                    <div class="htc__cart__total">
                                        <h6>tổng số hàng</h6>
                                        <div class="cart__desk__list">
                                            <ul class="cart__desc">
                                                <li>tổng số hàng</li>
                                                <li>thuế</li>
                                                <li>Converting row</li>
                                            </ul>
                                            <ul class="cart__price">
                                                <li>$909,00</li>
                                                <li>$9,00</li>
                                                <li>0</li>
                                            </ul>
                                        </div>
                                        <div class="cart__total">
                                            <span>tổng đơn hàng</span>
                                            <span>$918,00</span>
                                        </div>
                                        <ul class="payment__btn">
                                            <li class="active"><a href="#">sự trả tiền</a></li>
                                            <li><a href="#">continue mua sắm</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </form> 
                    </div>
                </div>
            </div>
        </div>
        <!-- cart-main-area end -->
        <!-- Start Brand Area -->
        <div class="htc__brand__area bg__cat--4">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="ht__brand__inner">
                            <ul class="brand__list owl-carousel clearfix">
                                <li><a href="#"><img src="../images/brand/1.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/2.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/3.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/4.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/5.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/5.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/1.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/2.png" alt="brand images"></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Brand Area -->
        <!-- Start Banner Area -->
        <div class="htc__banner__area">
            <ul class="banner__list owl-carousel owl-theme clearfix">
                <li><a href="../product-details"><img src="../images/banner/bn-3/1.jpg" alt="banner images"></a></li>
                <li><a href="../product-details"><img src="../images/banner/bn-3/2.jpg" alt="banner images"></a></li>
                <li><a href="../product-details"><img src="../images/banner/bn-3/3.jpg" alt="banner images"></a></li>
                <li><a href="../product-details"><img src="../images/banner/bn-3/4.jpg" alt="banner images"></a></li>
                <li><a href="../product-details"><img src="../images/banner/bn-3/5.jpg" alt="banner images"></a></li>
                <li><a href="../product-details"><img src="../images/banner/bn-3/6.jpg" alt="banner images"></a></li>
                <li><a href="../product-details"><img src="../images/banner/bn-3/1.jpg" alt="banner images"></a></li>
                <li><a href="../product-details"><img src="../images/banner/bn-3/2.jpg" alt="banner images"></a></li>
            </ul>
        </div>
        <!-- End Banner Area -->
        <!-- End Banner Area -->
        <!-- Start Footer Area -->
        <footer id="htc__footer">
            <!-- Start Footer Widget -->
            <div class="footer__container bg__cat--1">
                <div class="container">
                    <div class="row">
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-3 col-sm-6 col-xs-12">
                            <div class="footer">
                                <h2 class="title__line--2">Coming Up</h2>
                                <div class="ft__details">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisizing elit, sed do eiusmod tempor incididunt utlabore et dolore magna aliqua. Út cưng</p>
                                    <div class="ft__social__link">
                                        <ul class="social__link">
                                            <li><a href="#"><i class="icon-social-twitter icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-instagram icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-facebook icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-google icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-linkedin icons"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40">
                            <div class="footer">
                                <h2 class="title__line--2">Information</h2>
                                <div class="ft__inner">
                                    <ul class="ft__list">
                                        <li><a href="#">Về chúng tôi</a></li>
                                        <li><a href="#">Thông tin giao hàng</a></li>
                                        <li><a href="#">Chính sách bảo mật</a></li>
                                        <li><a href="#">Điều khoản & Điều kiện</a></li>
                                        <li><a href="#">sản xuất</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40 smt-40">
                            <div class="footer">
                                <h2 class="title__line--2">tài khoản của tôi</h2>
                                <div class="ft__inner">
                                    <ul class="ft__list">
                                        <li><a href="#">Tài khoản của tôi</a></li>
                                        <li><a href="../cart">Hàng hóa của tôi</a></li>
                                        <li><a href="#">Đăng nhập</a></li>
                                        <li><a href="../wishlist">danh sách yêu thích</a></li>
                                        <li><a href="../checkout">Thanh toán liên tục</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40 smt-40">
                            <div class="footer">
                                <h2 class="title__line--2">giao dịch của chúng tôi</h2>
                                <div class="ft__inner">
                                    <ul class="ft__list">
                                        <li><a href="#">Tài khoản của tôi</a></li>
                                        <li><a href="../cart">Hàng hóa của tôi</a></li>
                                        <li><a href="#">Đăng nhập</a></li>
                                        <li><a href="../wishlist">danh sách yêu thích</a></li>
                                        <li><a href="../checkout">Thanh toán liên tục</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-3 col-sm-6 col-xs-12 xmt-40 smt-40">
                            <div class="footer">
                                <h2 class="title__line--2">BẢN TIN</h2>
                                <div class="ft__inner">
                                    <div class="news__input">
                                        <input type="text" placeholder="Your Mail*">
                                        <div class="send__btn">
                                            <a class="fr__btn" href="#">Gửi thư</a>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                    </div>
                </div>
            </div>
            <!-- End Footer Widget -->
            <!-- Start Copyright Area -->
            <div class="htc__copyright bg__cat--5">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="copyright__inner">
                                <p>Copyright© <a href="https://freethemescloud.com/">Chủ đề miễn phí Đám mây</a>2018. Bảo lưu mọi quyền.</p>
                                <a href="#"><img src="../images/others/shape/paypol.png" alt="payment images"></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Copyright Area -->
        </footer>
        <!-- End Footer Style -->
    </div>
    <!-- Body main wrapper end -->

    <!-- Placed js at the end of the document so the pages load faster -->

    <!-- jquery latest version -->
    <script src="../js/vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap framework js -->
    <script src="../js/bootstrap.min.js"></script>
    <!-- All js plugins included in this file. -->
    <script src="../js/plugins.js"></script>
    <script src="../js/slick.min.js"></script>
    <script src="../js/owl.carousel.min.js"></script>
    <!-- Waypoints.min.js. -->
    <script src="../js/waypoints.min.js"></script>
    <!-- Main js file that contents all jQuery plugins activation. -->
    <script src="../js/main.js"></script>

</body>

</html>