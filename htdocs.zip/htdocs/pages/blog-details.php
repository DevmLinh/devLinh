<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Blog Chi Tiết || Asbab - Mẫu HTML5 thương mại điện tử</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Place favicon.ico in the root directory -->
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    

    <!-- All css files are included here. -->
    <!-- Bootstrap fremwork main css -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- Owl Carousel min css -->
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">
    <!-- This core.css file contents all plugings css file. -->
    <link rel="stylesheet" href="../css/core.css">
    <!-- Theme shortcodes/elements style -->
    <link rel="stylesheet" href="../css/shortcode/shortcodes.css">
    <!-- Theme main style -->
    <link rel="stylesheet" href="../style.css">
    <!-- Responsive css -->
    <link rel="stylesheet" href="../css/responsive.css">
    <!-- User style -->
    <link rel="stylesheet" href="../css/custom.css">


    <!-- Modernizr JS -->
    <script src="../js/vendor/modernizr-3.5.0.min.js"></script>
</head>

<body>
    <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>error time</strong> browser. Please <a href="http://browsehappy.com/">nâng cấp trình duyệt của bạn</a>để cải thiện trải nghiệm của bạn.</p>
    <![endif]-->  

    <!-- Body main wrapper start -->
    <div class="wrapper">
        <!-- Start Header Style -->
        <?php require_once('../pages/topmenu-header.php');?>
        <!-- End Header Area -->

        End Offset Wrapper -->
        <!-- Start Bradcaump area -->
        <div class="ht__bradcaump__area" style="background: rgba(0, 0, 0, 0) url(images/bg/5.jpg) no-repeat scroll center center / cover ;">
            <div class="ht__bradcaump__wrap">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="bradcaump__inner">
                                <nav class="bradcaump-inner">
                                  <a class="breadcrumb-item" href="../trang-chu">Trang Chủ</a>
                                  <span class="brd-separetor"><i class="zmdi zmdi-chevron-right"></i></span>
                                  <span class="breadcrumb-item active">Chi tiết blog</span>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Bradcaump area -->
        <!-- Start Blog Details Area -->
        <section class="htc__blog__details bg__white ptb--100">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-lg-12">
                        <div class="htc__blog__details__wrap">
                            <div class="ht__bl__thumb">
                                <img src="../images/blog/big-images/1.jpg" alt="blog images">
                            </div>
                            <div class="bl__dtl">
                                <p>Nhưng tôi phải giải thích cho bạn hiểu làm thế nào mà tất cả những ý tưởng tưởng tượng sai lầm về công việc lên niềm vui và ca ngợi nỗi đau này đã được sinh ra và tôi sẽ cung cấp cho bạn một bản tường trình đầy đủ về hệ thống hệ thống, đồng thời trình bày những lời dạy thực tế của nhà thám hiểm chân lý vĩ đại, nhà kiến ​​tạo bậc thầy của con người. niềm vui hạnh phúc. Không ai từ chối, ghét bỏ hay trốn tránh lạc thú bản thân nó, bởi vì nó là lạc thú, nhưng vì những ai không biết theo đuổi lạc thú một cách lý trí sẽ gặp phải những hậu quả vô cùng đau đớn. Lại nữa, không ai yêu thích, theo đuổi hay mong muốn có được nỗi nhớ cho riêng mình, bởi vì nó là nỗi nhớ, mà bởi vì đôi khi xảy ra những cảnh hoàn cảnh mà sự mệt mỏi và những điều có thể mang lại cho mình anh ta một niềm vui lớn nào đó. Lấy một ví dụ tầm thường,</p>

                                <p>Ai trong chúng ta từng tập thể dục kỳ lạ, ngoại trừ để đạt được một số lợi ích từ nó? Nhưng ai có quyền bắt lỗi một người chọn thú vui không gây hậu quả khó chịu, hay một người trốn tránh nỗi buồn không tạo ra cảm giác sảng khoái?”</p>
                                <blockquote>Không ai từ chối, không thích hoặc tránh né niềm vui, bởi vì nó là niềm vui, nhưng bởi vì những người không biết cách theo đuổi niềm vui sẽ gặp phải những hậu quả như vậy. được sinh ra và tôi sẽ cung cấp cho bạn một tài khoản hoàn chỉnh về hệ thống, đồng thời trình bày những lời dạy thực tế của nhà thám hiểm vĩ đại về sự thật, bậc thầy xây dựng hạnh phúc của con người.</blockquote>

                                <p>Nhưng tôi phải giải thích cho bạn hiểu làm thế nào mà tất cả những ý tưởng tưởng tượng sai lầm về công việc lên niềm vui và ca ngợi nỗi đau này đã được sinh ra và tôi sẽ cung cấp cho bạn một bản tường trình đầy đủ về hệ thống hệ thống, đồng thời trình bày những lời dạy thực tế của nhà thám hiểm chân lý vĩ đại, nhà kiến ​​tạo bậc thầy của con người. niềm vui hạnh phúc.</p>
                                <p>Nhưng tôi phải giải thích cho bạn hiểu làm thế nào mà tất cả những ý tưởng tưởng tượng sai lầm về công việc lên niềm vui và ca ngợi nỗi đau này đã được sinh ra và tôi sẽ cung cấp cho bạn một bản tường trình đầy đủ về hệ thống hệ thống, đồng thời trình bày những lời dạy thực tế của nhà thám hiểm chân lý vĩ đại, nhà kiến ​​tạo bậc thầy của con người. niềm vui hạnh phúc.</p>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="bl__img">
                                            <img src="../images/blog/md-img/1.jpg" alt="blog images">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="bl__img">
                                            <img src="../images/blog/md-img/2.jpg" alt="blog images">
                                        </div>
                                    </div>
                                </div>
                                <p>Nhưng tôi phải giải thích cho bạn hiểu làm thế nào mà tất cả những ý tưởng tưởng tượng sai lầm về công việc lên niềm vui và ca ngợi nỗi đau này đã được sinh ra và tôi sẽ cung cấp cho bạn một bản tường trình đầy đủ về hệ thống hệ thống, đồng thời trình bày những lời dạy thực tế của nhà thám hiểm chân lý vĩ đại, nhà kiến ​​tạo bậc thầy của con người. niềm vui hạnh phúc.</p>
                                <p>Nhưng tôi phải giải thích cho bạn hiểu làm thế nào mà tất cả những ý tưởng tưởng tượng sai lầm về công việc lên niềm vui và ca ngợi nỗi đau này đã được sinh ra và tôi sẽ cung cấp cho bạn một bản tường trình đầy đủ về hệ thống hệ thống, đồng thời trình bày những lời dạy thực tế của nhà thám hiểm chân lý vĩ đại, nhà kiến ​​tạo bậc thầy của con người. niềm vui hạnh phúc.</p>
                            </div>
                            <!-- Start Comment Area -->
                            <div class="htc__comment__area">
                                <h4 class="title__line--5">CÓ 2 Ý KIẾN</h4>
                                <div class="ht__comment__content">
                                    <!-- Start Single Comment -->
                                    <div class="comment">
                                        <div class="comment__thumb">
                                            <img src="../images/comment/1.png" alt="comment images">
                                        </div>
                                        <div class="ht__comment__details">
                                            <div class="ht__comment__title">
                                                <h2><a href="#">JOHN NGUYỄN</a></h2>
                                                <div class="reply__btn">
                                                    <a href="#">Remake</a>
                                                </div>
                                            </div>
                                            <span>Tháng Bảy 15, 2016 lúc 2:39 sáng</span>
                                            <p>Gian hàng chụp ảnh thực tế túi tote Stumptown Banksy, elit freegan sed lô nhỏ.</p>
                                        </div>
                                    </div>
                                    <!-- End Single Comment -->
                                    <!-- Start Single Comment -->
                                    <div class="comment comment--reply">
                                        <div class="comment__thumb">
                                            <img src="../images/comment/2.png" alt="comment images">
                                        </div>
                                        <div class="ht__comment__details">
                                            <div class="ht__comment__title">
                                                <h2><a href="#">JOHN NGUYỄN</a></h2>
                                                <div class="reply__btn">
                                                    <a href="#">Remake</a>
                                                </div>
                                            </div>
                                            <span>Tháng Bảy 15, 2016 lúc 2:39 sáng</span>
                                            <p>Gian hàng chụp ảnh thực tế túi tote Stumptown Banksy, elit freegan sed lô nhỏ.</p>
                                        </div>
                                    </div>
                                    <!-- End Single Comment -->
                                    <!-- Start Single Comment -->
                                    <div class="comment">
                                        <div class="comment__thumb">
                                            <img src="../images/comment/3.png" alt="comment images">
                                        </div>
                                        <div class="ht__comment__details">
                                            <div class="ht__comment__title">
                                                <h2><a href="#">JOHN NGUYỄN</a></h2>
                                                <div class="reply__btn">
                                                    <a href="#">Remake</a>
                                                </div>
                                            </div>
                                            <span>Tháng Bảy 15, 2016 lúc 2:39 sáng</span>
                                            <p>Gian hàng chụp ảnh thực tế túi tote Stumptown Banksy, elit freegan sed lô nhỏ.</p>
                                        </div>
                                    </div>
                                    <!-- End Single Comment -->
                                </div>
                            </div>
                            <!-- End Comment Area -->
                            <!-- Start comment Form -->
                            <div class="ht__comment__form">
                                <h4 class="title__line--5">To back comment</h4>
                                <div class="ht__comment__form__inner">
                                    <div class="comment__form">
                                        <input type="text" placeholder="Name *">
                                        <input type="email" placeholder="Email *">
                                        <input type="text" placeholder="Website">
                                    </div>
                                    <div class="comment__form message">
                                        <textarea name="message"  placeholder="Your Comment"></textarea>
                                    </div>
                                </div>
                                <div class="ht__comment__btn--2 mt--30">
                                    <a class="fr__btn" href="#">Gửi</a>
                                </div>
                            </div>
                            <!-- End comment Form -->
                            
                        </div>
                    </div>  
                </div>
            </div>
        </section>
        <!-- End Blog Details Area -->
        <!-- Start Footer Area -->
        <footer id="htc__footer">
            <!-- Start Footer Widget -->
            <div class="footer__container bg__cat--1">
                <div class="container">
                    <div class="row">
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-3 col-sm-6 col-xs-12">
                            <div class="footer">
                                <h2 class="title__line--2">Coming Up</h2>
                                <div class="ft__details">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisizing elit, sed do eiusmod tempor incididunt utlabore et dolore magna aliqua. Út cưng</p>
                                    <div class="ft__social__link">
                                        <ul class="social__link">
                                            <li><a href="#"><i class="icon-social-twitter icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-instagram icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-facebook icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-google icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-linkedin icons"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40">
                            <div class="footer">
                                <h2 class="title__line--2">Information</h2>
                                <div class="ft__inner">
                                    <ul class="ft__list">
                                        <li><a href="#">Về chúng tôi</a></li>
                                        <li><a href="#">Thông tin giao hàng</a></li>
                                        <li><a href="#">Chính sách bảo mật</a></li>
                                        <li><a href="#">Điều khoản & Điều kiện</a></li>
                                        <li><a href="#">sản xuất</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40 smt-40">
                            <div class="footer">
                                <h2 class="title__line--2">tài khoản của tôi</h2>
                                <div class="ft__inner">
                                    <ul class="ft__list">
                                        <li><a href="#">Tài khoản của tôi</a></li>
                                        <li><a href="../cart">Hàng hóa của tôi</a></li>
                                        <li><a href="#">Đăng nhập</a></li>
                                        <li><a href="../wishlist">danh sách yêu thích</a></li>
                                        <li><a href="../checkout">Thanh toán liên tục</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40 smt-40">
                            <div class="footer">
                                <h2 class="title__line--2">giao dịch của chúng tôi</h2>
                                <div class="ft__inner">
                                    <ul class="ft__list">
                                        <li><a href="#">Tài khoản của tôi</a></li>
                                        <li><a href="../cart">Hàng hóa của tôi</a></li>
                                        <li><a href="#">Đăng nhập</a></li>
                                        <li><a href="../wishlist">danh sách yêu thích</a></li>
                                        <li><a href="../checkout">Thanh toán liên tục</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-3 col-sm-6 col-xs-12 xmt-40 smt-40">
                            <div class="footer">
                                <h2 class="title__line--2">BẢN TIN</h2>
                                <div class="ft__inner">
                                    <div class="news__input">
                                        <input type="text" placeholder="Your Mail*">
                                        <div class="send__btn">
                                            <a class="fr__btn" href="#">Gửi thư</a>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                    </div>
                </div>
            </div>
            <!-- End Footer Widget -->
            <!-- Start Copyright Area -->
            <div class="htc__copyright bg__cat--5">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="copyright__inner">
                                <p>Copyright© <a href="https://freethemescloud.com/">Chủ đề miễn phí Đám mây</a>2018. Bảo lưu mọi quyền.</p>
                                <a href="#"><img src="../images/others/shape/paypol.png" alt="payment images"></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Copyright Area -->
        </footer>
        <!-- End Footer Style -->
    </div>
    <!-- Body main wrapper end -->

    <!-- Placed js at the end of the document so the pages load faster -->

    <!-- jquery latest version -->
    <script src="../js/vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap framework js -->
    <script src="../js/bootstrap.min.js"></script>
    <!-- All js plugins included in this file. -->
    <script src="../js/plugins.js"></script>
    <script src="../js/slick.min.js"></script>
    <script src="../js/owl.carousel.min.js"></script>
    <!-- Waypoints.min.js. -->
    <script src="../js/waypoints.min.js"></script>
    <!-- Main js file that contents all jQuery plugins activation. -->
    <script src="../js/main.js"></script>

</body>

</html>