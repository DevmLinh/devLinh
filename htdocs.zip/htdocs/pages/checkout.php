<?php
require_once('../admin/config.php');

if (!isset($_SESSION['_page_dh'])) {
    $_SESSION['_page_dh'] = '1';
}

if (isset($_GET['page'])) {
    $_SESSION['_page_dh'] = $_GET['page'];
}


$_SESSION['muahang'] = 0;
if (!isset($_SESSION['username'])) {
    echo "<script>confirm('Bạn phải đăng nhập để thực hiện thao tác này.');</script>";
    echo '<script>window.location = "../dang-nhap";</script>';
    $_SESSION['muahang'] = 1;
}


if (isset($_GET['chinhsua']) and isset($_GET['soluong'])) {
    $_SESSION['arrgiohang'][str_replace("ip", "", $_GET['chinhsua'])]["soluong"] = $_GET['soluong'];
    echo '<script>window.location = "../checkout";</script>';
}

if (isset($_GET['xoagiohang'])) {
    $xoa = $_GET['xoagiohang'];

    $data_sp = $ketnoi->query("SELECT * FROM `san_pham` WHERE `ma_sp` = '" . $_SESSION['arrgiohang1'][$xoa] . "'")->fetch_array();
    $ten_sp = $data_sp['ten_sp'];

    array_splice($_SESSION['arrgiohang'], $xoa, 1);
    array_splice($_SESSION['arrgiohang1'], $xoa, 1);
    echo "<script>confirm('Bạn đã xóa [ " . $ten_sp . " ] ra khỏi giỏ hàng giỏ hàng.');</script>";
    echo '<meta http-equiv="refresh" content="0;url=../checkout">';
}



if (isset($_POST['post_muahang'])) {

    //INSERT INTO `muahang`(`taikhoan`, `madonhang`, `json_hang`, `json_phi`, `thoigian`, `trangthai`) VALUES ('','','','','','')


    if (isset($_SESSION['arrgiohang'])) {
        $tongtien = 0;
        $sl_sp_1 = 0;
        if (count($_SESSION['arrgiohang']) > 0) {
            for ($hh = 0; $hh < count($_SESSION['arrgiohang']); $hh++) {
                $masp = $_SESSION['arrgiohang'][$hh]["masp"];
                $sl_sp = $_SESSION['arrgiohang'][$hh]["soluong"];
                $sl_sp_1 = $sl_sp_1 + $sl_sp;
                $data_sp = $ketnoi->query("SELECT * FROM `san_pham` WHERE `ma_sp` = '" . $masp . "'")->fetch_array();

                $masp = $data_sp['ma_sp'];
                $giasp = $data_sp['gia_sp'];
                $ténsp = $data_sp['ten_sp'];

                //$ténsp = sub_name($ténsp, 20) . '...';
                $img = $data_sp['anh_sp'];
                $img = explode(",", $img)[rand(0, 2)];
                $trangthai = $data_sp['trangthai_sp'];

                $tongtien = ($tongtien + $giasp) * $sl_sp;
            }

            $phi_vanchuyen = $sl_sp_1 * 5000;

            $madh = "DH_" . get_random_string(5);

            $json_hang = json_encode($_SESSION['arrgiohang']);
            $json_phi = json_encode(array("tongtien" => $tongtien, "phi_vanchuyen" => $phi_vanchuyen));
            //$json_dia_chi = json_encode(array("hoten"=> $user['hoten'], "diachi" => $user['diachi'], "dienthoai" => $user['dienthoai']),true);

            $sql_muahang = "INSERT INTO `muahang`(`taikhoan`, `madonhang`, `json_hang`, `json_phi`, `thoigian`, `trangthai`) 
            VALUES ('" . $_SESSION['username'] . "','" . $madh . "','" . $json_hang . "','" . $json_phi . "','" . date("Y-m-d H:i:s") . "','1')";

            $mua_dh = $ketnoi->query($sql_muahang);
            if ($mua_dh) {
                $_SESSION['arrgiohang'] = [];
                $_SESSION['arrgiohang1'] = [];

                echo "<script>confirm('Mua hàng thành công.');</script>";
                echo '<meta http-equiv="refresh" content="1;url=../checkout">';
            } else {
                echo "<script>confirm('Mua hàng thất bại.');</script>";
            }
        } else {
            echo "<script>confirm('Giỏ hàng trống.');</script>";
        }
    }
}



if (isset($_POST['cn_hoten']) and isset($_POST['cn_diachi']) and isset($_POST['cn_sdt'])) {
    $hoten = $_POST['cn_hoten'];
    $diachi = $_POST['cn_diachi'];
    $sdt = $_POST['cn_sdt'];

    $sql_capnhat = "UPDATE `users` SET `hoten`='" . $hoten . "',`dienthoai`='" . $sdt . "',`diachi`='" . $diachi . "' WHERE `taikhoan` = '" . $_SESSION['username'] . "'";
    $_cn = $ketnoi->query($sql_capnhat);
    if ($_cn) {
        echo "<script>confirm('Cập nhật địa chỉ thành công.');</script>";
        echo '<script>window.location="../checkout";</script>';
    } else {
        echo "<script>confirm('Cập nhật địa chỉ thất bại.');</script>";
    }
}



function get_random_string($length)
{
    $valid_chars = "QWERTYUIOPASDFGHJKLZXCVBNM1234567890";
    $random_string = "";
    $num_valid_chars = strlen($valid_chars);
    for ($i = 0; $i < $length; $i++) {
        $random_pick = mt_Rand(1, $num_valid_chars);
        $random_char = $valid_chars[$random_pick - 1];
        $random_string .= $random_char;
    }
    return $random_string;
}


?>


<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Thanh toán || Asbab - Mẫu HTML5 thương mại điện tử</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Place favicon.ico in the root directory -->
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">


    <!-- All css files are included here. -->
    <!-- Bootstrap fremwork main css -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- Owl Carousel min css -->
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">
    <!-- This core.css file contents all plugings css file. -->
    <link rel="stylesheet" href="../css/core.css">
    <!-- Theme shortcodes/elements style -->
    <link rel="stylesheet" href="../css/shortcode/shortcodes.css">
    <!-- Theme main style -->
    <link rel="stylesheet" href="../style.css">
    <!-- Responsive css -->
    <link rel="stylesheet" href="../css/responsive.css">
    <!-- User style -->
    <link rel="stylesheet" href="../css/custom.css">


    <!-- Modernizr JS -->
    <script src="../js/vendor/modernizr-3.5.0.min.js"></script>

    <style>
        .wishlist-table table td {

            font-weight: 60;
            padding: 5px 5px;
            text-align: center;
        }
    </style>
</head>

<body>
    <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>error time</strong> browser. Please <a href="http://browsehappy.com/">nâng cấp trình duyệt của bạn</a>để cải thiện trải nghiệm của bạn.</p>
    <![endif]-->

    <!-- Body main wrapper start -->
    <div class="wrapper">
        <!-- Start Header Style -->
        <?php require_once('../pages/topmenu-header.php'); ?>
        <!-- End Header Area -->
        <!-- Start Bradcaump area -->
        <div class="ht__bradcaump__area" style="background: rgba(0, 0, 0, 0) url(images/bg/5.jpg) no-repeat scroll center center / cover ;">
            <div class="ht__bradcaump__wrap">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="bradcaump__inner">
                                <nav class="bradcaump-inner">
                                    <a class="breadcrumb-item" href="../trang-chu">Trang Chủ</a>
                                    <span class="brd-separetor"><i class="zmdi zmdi-chevron-right"></i></span>
                                    <span class="breadcrumb-item active">Thanh toán liên tục</span>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Bradcaump area -->
        <!-- cart-main-area start -->
        <div class="checkout-wrap ptb--100">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <div class="order-details">
                            <h5 class="order-details__title">GIỎ HÀNG</h5>
                            <div class="order-details__item">
                                <form action="" method="POST" id="form_sp">
                                    <?php
                                    if (isset($_SESSION['arrgiohang'])) {
                                        $tongtien = 0;
                                        $sl_sp_1 = 0;
                                        for ($hh = 0; $hh < count($_SESSION['arrgiohang']); $hh++) {
                                            $masp = $_SESSION['arrgiohang'][$hh]["masp"];
                                            $sl_sp = $_SESSION['arrgiohang'][$hh]["soluong"];
                                            $sl_sp_1 = $sl_sp_1 + $sl_sp;
                                            $data_sp = $ketnoi->query("SELECT * FROM `san_pham` WHERE `ma_sp` = '" . $masp . "'")->fetch_array();

                                            $masp = $data_sp['ma_sp'];
                                            $giasp = $data_sp['gia_sp'];
                                            $ténsp = $data_sp['ten_sp'];

                                            //$ténsp = sub_name($ténsp, 20) . '...';
                                            $img = $data_sp['anh_sp'];
                                            $img = explode(",", $img)[rand(0, 2)];
                                            $trangthai = $data_sp['trangthai_sp'];

                                            $tongtien = ($tongtien + $giasp) * $sl_sp;
                                    ?>
                                            <div class="single-item">
                                                <div class="single-item__thumb">
                                                    <img src="<?= $img ?>" alt="ordered item">
                                                </div>
                                                <div class="single-item__content">
                                                    <a href="#"><?= $ténsp ?></a>
                                                    <span class="price"><?= tien($giasp) ?>đ</span>
                                                    <span class="quantity">Số lượng: <input type="number" value="<?= $sl_sp ?>" style="width: 50px;border: aqua;" id="<?= 'ip' . $hh ?>" onchange="load_hang('<?= 'ip' . $hh ?>')"></span>
                                                </div>
                                                <div class="single-item__remove">
                                                    <a href="../checkout/?xoagiohang=<?= $hh ?>"><i class="zmdi zmdi-delete"></i></a>
                                                </div>
                                            </div>
                                    <?php
                                        }
                                    }
                                    $phi_vanchuyen = $sl_sp_1 * 5000;
                                    ?>
                                </form>
                            </div>
                            <div class="order-details__count">
                                <div class="order-details__count__single">
                                    <h5>Tổng tiền đơn hàng:</h5>
                                    <span class="price"><?= tien($tongtien) ?>đ</span>
                                </div>
                                <div class="order-details__count__single">
                                    <h5>Phí vận chuyển</h5>
                                    <span class="price"><?= tien($phi_vanchuyen) ?>đ</span>
                                </div>
                            </div>
                            <div class="ordre-details__total">
                                <h5>Thành tiền:</h5>
                                <span class="price"><?= tien($tongtien + $phi_vanchuyen) ?>đ</span>
                            </div>
                            <div class="ordre-details__total">
                                <form action="" method="POST" id="form_sp" style="width: 100%;">
                                    <input type="submit" name="post_muahang" value="MUA HÀNG" style="background-color: #ff2727;width: 100%;color:aliceblue;border: none;font-weight: bold;padding: 5px;font-family: 'Poppins';">
                                </form>
                            </div>
                        </div><br><br>
                    </div>
                    <div class="col-md-4">
                        <div class="checkout__inner">
                            <div class="accordion-list">
                                <div class="accordion">
                                    <div class="accordion__title">ĐỊA CHỈ NHẬN HÀNG</div>
                                    <div class="accordion__body">
                                        <div class="bilinfo">
                                            <form action="" method="POST">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="single-input">
                                                            <input type="text" value="VIỆT NAM" disabled>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="single-input">
                                                            <input type="text" placeholder="Họ và tên" name="cn_hoten" value="<?= $user['hoten'] ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="single-input">
                                                            <input type="text" placeholder="Số điện thoại" name="cn_sdt" value="<?= $user['dienthoai'] ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <div class="single-input">
                                                            <textarea name="cn_diachi" style="    background: #ffffff; border: 1px solid black" placeholder="Nhập địa chỉ*"><?= $user['diachi'] ?></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="single-input">
                                                            <input type="submit" value="CẬP NHẬT THÔNG TIN" name="capnhatthongtin" style="background-color: #ff2727;color: aliceblue;">
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>








                </div>

                <div class="row">
                    <div class="col-md-12">
                        

                    <div class="order-details" style="background-color: #e8e8e8;">
                            <h5 class="order-details__title">QUẢN LÝ ĐƠN HÀNG</h5>
                            <div class="wishlist-table table-responsive">
                                <table>
                                    <thead>
                                        <tr>
                                            <th class="product-thumbnail" style="width: 5px;"><span>STT</span></th>
                                            <th class="product-thumbnail" style="width: 590px;">Đơn hàng</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $dau_page_donhange = ($_SESSION['_page_dh'] * 3) - 3;

                                        $query_sp = $ketnoi->query("SELECT * FROM `muahang` WHERE `taikhoan` = '" . $_SESSION['username'] . "' ORDER BY `id` DESC");
                                        $stt = 0;

                                        while ($row = mysqli_fetch_array($query_sp)) {
                                            $stt++;
                                            if ($stt >= $dau_page_donhange and $stt <= $dau_page_donhange + 3) {
                                                $tongtien = 0;
                                                $sl_sp_1 = 0;

                                                $madon = $row['madonhang'];
                                                $json_hang = $row['json_hang'];
                                                $json_hang = json_decode($json_hang, true);
                                                $json_phi = $row['json_phi'];
                                                $json_phi = json_decode($json_phi, true);
                                                $phi_ship = $json_phi['phi_vanchuyen'];
                                                $tong_phi = $json_phi['phi_vanchuyen'];
                                                $thoigian = $row['thoigian'];
                                                $trangthai = $row['trangthai'];
                                                if ($trangthai == 1) {
                                                    $kq_tt = '<span style="font-weight: 500;font-family: sans-serif;background-color: aquamarine;padding: 4px;border-radius: 4px;">Đang giao hàng</span>';
                                                } else if ($trangthai == 2) {
                                                    $kq_tt = '<span style="font-weight: 500;font-family: sans-serif;background-color: chartreuse;padding: 4px;border-radius: 4px;">Giao hàng thành công</span>';
                                                } else {
                                                    $kq_tt = '<span style="font-weight: 500;font-family: sans-serif;background-color: gray;padding: 4px;border-radius: 4px;">Giao hàng thất bại</span>';
                                                }

                                                ?>
                                            <tr>
                                                <td class="product-thumbnail" style="width: 5px;"><a><?= $stt ?></a></td>
                                                <td class="product-thumbnail" style="padding: 0 0px; border: 0px solid black;">

                                                    <table>
                                                        <thead>
                                                            <tr>
                                                                <th><span>STT</span></th>
                                                                <th class="product-thumbnail" style="max-width: 111px;">HÌNH ẢNH</th>
                                                                <th class="product-thumbnail" style="width: 700px;">THÔNG TIN CHI TIẾT</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php
                                                            $stt1 = 0;
                                                            for ($i_hang = 0; $i_hang < count($json_hang); $i_hang++) {
                                                                $stt1++;
                                                                $h_masp = $json_hang[$i_hang]['masp'];
                                                                $h_slsp = $json_hang[$i_hang]['soluong'];
                                                                $sl_sp_1 = $sl_sp_1 + $h_slsp;

                                                                $data_sp = $ketnoi->query("SELECT * FROM `san_pham` WHERE `ma_sp` = '" . $h_masp . "'")->fetch_array();

                                                                $masp = $data_sp['ma_sp'];
                                                                $giasp = $data_sp['gia_sp'];
                                                                $ténsp = $data_sp['ten_sp'];

                                                                //$ténsp = sub_name($ténsp, 20) . '...';
                                                                $img = $data_sp['anh_sp'];
                                                                $img = explode(",", $img)[rand(0, 2)];
                                                                $trangthai = $data_sp['trangthai_sp'];
                                                                $tongtien = ($tongtien + $giasp) * $h_slsp;
                                                                ?>
                                                                <tr>
                                                                    <td rowspan="4"><a><?= $stt1 ?></a></td>
                                                                    <td rowspan="4">
                                                                        <a href="../product-details/?masp=<?= $masp ?>"><img src="<?= $img ?>" alt="product images"></a>
                                                                    </td>
                                                                    <td>
                                                                        MÃ: <?= $h_masp ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        TÊN SP: <?= $ténsp ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        GIÁ BÁN: <?= $giasp ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        SỐ LƯỢNG: <?= $h_slsp ?>
                                                                    </td>
                                                                </tr>
                                                            <?php
                                                            }
                                                            $phi_vanchuyen = $sl_sp_1 * 5000;
                                                            ?>
                                                            <tr>
                                                                <td colspan="2" style="font-size: 13px;text-align: left;padding-left: 6px;background-color: #f4ffca;">
                                                                    Phí ship: <span style="background-color: #00ffd2;border-radius: 3px;"><?= tien($phi_ship) ?>đ</span><br>
                                                                    TỔNG ĐƠN HÀNG: <span style="background-color: darkorange;border-radius: 3px;"><?= tien($tong_phi) ?>đ</span><br>
                                                                    Trạng thái đơn hàng: <?= $kq_tt ?>
                                                                </td>
                                                                <td colspan="1" style="text-align: left; padding-left: 30px; background-color: #f4ffca;">
                                                                    Họ tên: <?=$user['hoten']?><br/>
                                                                    Số điện thoại: <?=$user['dienthoai']?><br/>
                                                                    Địa chi: <?=$user['diachi']?><br/>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>

                                                </td>
                                            </tr>
                                        <?php
                                            }
                                        }
                                        ?>
                                    </tbody>
                                </table>

                            </div>

                        </div>

                        <!-- Start Pagenation -->
                        <div class="row">
                            <div class="col-xs-12">
                                <ul class="htc__pagenation">
                                    <li><a href="../checkout/?page=<?= ($_SESSION['_page_dh'] - 1) ?>"><i class="zmdi zmdi-chevron-left"></i></a></li>
                                    <?php
                                    if ($_SESSION['_page_dh'] > 1) {
                                        echo '<li ><a href="../checkout/?page=' . ($_SESSION['_page_dh'] - 1) . '">' . ($_SESSION['_page_dh'] - 1) . '</a></li>';
                                    }
                                    ?>
                                    <li class="active"><a href="../checkout/?page=<?= ($_SESSION['_page_dh']) ?>"><?= ($_SESSION['_page_dh']) ?></a></li>
                                    <?php
                                    if ($stt > 3 and $_SESSION['_page_dh'] < ceil($stt / 3)) {
                                        echo '<li ><a href="../checkout/?page=' . ($_SESSION['_page_dh'] + 1) . '">' . ($_SESSION['_page_dh'] + 1) . '</a></li>';
                                    }
                                    ?>
                                    <?php
                                    if ($_SESSION['_page_dh'] + 1 < ceil($stt / 3)) {
                                    ?>
                                        <li><a href="">...</a></li>
                                        <li><a href="../checkout/?page=<?= ceil($stt / 3) ?>"><?= ceil($stt / 3) ?></a></li>
                                    <?php } ?>
                                    <li><a href="../checkout/?page=<?= ($_SESSION['_page_dh'] + 1) ?>"><i class="zmdi zmdi-chevron-right"></i></a></li>
                                </ul>
                            </div>
                        </div><br><br>
                        <!-- End Pagenation -->


                    </div>
                </div>

            </div>
        </div>
        <!-- cart-main-area end -->
        <!-- Start Brand Area -->
        <div class="htc__brand__area bg__cat--4">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="ht__brand__inner">
                            <ul class="brand__list owl-carousel clearfix">
                                <li><a href="#"><img src="../images/brand/1.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/2.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/3.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/4.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/5.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/5.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/1.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/2.png" alt="brand images"></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Brand Area -->
        <!-- Start Footer Area -->
        <footer id="htc__footer">
            <!-- Start Footer Widget -->
            <div class="footer__container bg__cat--1">
                <div class="container">
                    <div class="row">
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-3 col-sm-6 col-xs-12">
                            <div class="footer">
                                <h2 class="title__line--2">Coming Up</h2>
                                <div class="ft__details">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisizing elit, sed do eiusmod tempor incididunt utlabore et dolore magna aliqua. Út cưng</p>
                                    <div class="ft__social__link">
                                        <ul class="social__link">
                                            <li><a href="#"><i class="icon-social-twitter icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-instagram icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-facebook icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-google icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-linkedin icons"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40">
                            <div class="footer">
                                <h2 class="title__line--2">Information</h2>
                                <div class="ft__inner">
                                    <ul class="ft__list">
                                        <li><a href="#">Về chúng tôi</a></li>
                                        <li><a href="#">Thông tin giao hàng</a></li>
                                        <li><a href="#">Chính sách bảo mật</a></li>
                                        <li><a href="#">Điều khoản & Điều kiện</a></li>
                                        <li><a href="#">sản xuất</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40 smt-40">
                            <div class="footer">
                                <h2 class="title__line--2">tài khoản của tôi</h2>
                                <div class="ft__inner">
                                    <ul class="ft__list">
                                        <li><a href="#">Tài khoản của tôi</a></li>
                                        <li><a href="../cart">Hàng hóa của tôi</a></li>
                                        <li><a href="#">Đăng nhập</a></li>
                                        <li><a href="../wishlist">danh sách yêu thích</a></li>
                                        <li><a href="../checkout">Thanh toán liên tục</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40 smt-40">
                            <div class="footer">
                                <h2 class="title__line--2">giao dịch của chúng tôi</h2>
                                <div class="ft__inner">
                                    <ul class="ft__list">
                                        <li><a href="#">Tài khoản của tôi</a></li>
                                        <li><a href="../cart">Hàng hóa của tôi</a></li>
                                        <li><a href="#">Đăng nhập</a></li>
                                        <li><a href="../wishlist">danh sách yêu thích</a></li>
                                        <li><a href="../checkout">Thanh toán liên tục</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-3 col-sm-6 col-xs-12 xmt-40 smt-40">
                            <div class="footer">
                                <h2 class="title__line--2">BẢN TIN</h2>
                                <div class="ft__inner">
                                    <div class="news__input">
                                        <input type="text" placeholder="Your Mail*">
                                        <div class="send__btn">
                                            <a class="fr__btn" href="#">Gửi thư</a>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                    </div>
                </div>
            </div>
            <!-- End Footer Widget -->
            <!-- Start Copyright Area -->
            <div class="htc__copyright bg__cat--5">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="copyright__inner">
                                <p>Copyright© <a href="https://freethemescloud.com/">Chủ đề miễn phí Đám mây</a>2018. Bảo lưu mọi quyền.</p>
                                <a href="#"><img src="../images/others/shape/paypol.png" alt="payment images"></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Copyright Area -->
        </footer>
        <!-- End Footer Style -->
    </div>
    <!-- Body main wrapper end -->

    <!-- Placed js at the end of the document so the pages load faster -->

    <!-- jquery latest version -->
    <script src="../js/vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap framework js -->
    <script src="../js/bootstrap.min.js"></script>
    <!-- All js plugins included in this file. -->
    <script src="../js/plugins.js"></script>
    <script src="../js/slick.min.js"></script>
    <script src="../js/owl.carousel.min.js"></script>
    <!-- Waypoints.min.js. -->
    <script src="../js/waypoints.min.js"></script>
    <!-- Main js file that contents all jQuery plugins activation. -->
    <script src="../js/main.js"></script>
    <script>
        function load_hang(x) {
            var inputVal = document.getElementById(x).value;
            window.location = "../checkout/?chinhsua=" + x + "&soluong=" + inputVal;
        }
    </script>
</body>

</html>