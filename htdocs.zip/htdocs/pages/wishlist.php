<?php
require_once('../admin/config.php');

if (!isset($_SESSION['username'])) {
    echo "<script>confirm('Bạn phải đăng nhập để thực hiện thao tác này.');</script>";
    echo '<script>window.location = "../dang-nhap";</script>';
}



if (isset($_GET['huyyeuthich'])) {
    $ma_yt = $_GET['huyyeuthich'];
    $check_hh = mysqli_num_rows(mysqli_query($ketnoi, "SELECT * FROM yeu_thich WHERE taikhoan ='".$_SESSION['username']."' and `ma_sp` = '".$ma_yt."'"));
    if ($check_hh != '') {
        $sql_yt = "DELETE FROM `yeu_thich` WHERE `ma_sp` = '".$ma_yt."' and `taikhoan` = '".$_SESSION['username']."'";
        $_yt = $ketnoi->query($sql_yt);
        $data_sp = $ketnoi->query("SELECT * FROM `san_pham` WHERE `ma_sp` = '".$ma_yt."'")->fetch_array();
        $luot_yt = $data_sp['sl_yeuthich'];
        $sql_yt = "UPDATE `san_pham` SET `sl_yeuth1' = '" . ($luot_yt-1) . "' WHERE `ma_sp` = '" . $ma_yt . "'";
        echo "<script>confirm('Bạn bỏ yêu thích.');</script>";
    }
    echo '<meta http-equiv="refresh" content="0;url=../wishlist">';
}



if (isset($_GET['themgiohang'])) {
    $data_sp = $ketnoi->query("SELECT * FROM `san_pham` WHERE `ma_sp` = '" . $_GET['themgiohang'] . "'")->fetch_array();
    if ($data_sp['id_sp'] != '') {
        $ma_sp = $_GET['themgiohang'];
        $ten_sp = $data_sp['ten_sp'];
        $sl_sp  = $data_sp['soluong_sp'];
        $gia_sp = $data_sp['gia_sp'];
        $trangthai_sp = $data_sp['trangthai_sp'];

        if (in_array($_GET['themgiohang'], $_SESSION['arrgiohang1'])) {
            for ($cc = 0; $cc < count($_SESSION['arrgiohang']); $cc++) {
                if ($_SESSION['arrgiohang'][$cc]["masp"] == $ma_sp) {
                    $soluong_spht = $_SESSION['arrgiohang'][$cc]["soluong"];
                    $soluong_spht = $soluong_spht + 1;
                    $_SESSION['arrgiohang'][$cc]["soluong"] = $soluong_spht;
                    echo "<script>confirm('Bạn đã thêm [" . $soluong_spht . "] [ " . $ten_sp . " ] vào giỏ hàng.');</script>";
                    break;
                }
            }
        } else {


            array_push($_SESSION['arrgiohang'], array("masp" => $_GET['themgiohang'], "soluong" => "1"));
            array_push($_SESSION['arrgiohang1'], $_GET['themgiohang']);
            echo "<script>confirm('Bạn đã thêm [ " . $ten_sp . " ] vào giỏ hàng.');</script>";
        }
    } else {
        echo "<script>confirm('Mã sản phẩm [ " . $_GET['themgiohang'] . " ] không tồn tại.');</script>";
    }
    echo '<meta http-equiv="refresh" content="0;url=../wishlist">';
}


?>


<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Danh sách yêu thích || Asbab - Mẫu HTML5 thương mại điện tử</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Place favicon.ico in the root directory -->
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">


    <!-- All css files are included here. -->
    <!-- Bootstrap fremwork main css -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- Owl Carousel min css -->
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">
    <!-- This core.css file contents all plugings css file. -->
    <link rel="stylesheet" href="../css/core.css">
    <!-- Theme shortcodes/elements style -->
    <link rel="stylesheet" href="../css/shortcode/shortcodes.css">
    <!-- Theme main style -->
    <link rel="stylesheet" href="../style.css">
    <!-- Responsive css -->
    <link rel="stylesheet" href="../css/responsive.css">
    <!-- User style -->
    <link rel="stylesheet" href="../css/custom.css">


    <!-- Modernizr JS -->
    <script src="../js/vendor/modernizr-3.5.0.min.js"></script>
</head>

<body>
    <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>error time</strong> browser. Please <a href="http://browsehappy.com/">nâng cấp trình duyệt của bạn</a>để cải thiện trải nghiệm của bạn.</p>
    <![endif]-->

    <!-- Body main wrapper start -->
    <div class="wrapper">
        <!-- Start Header Style -->
        <?php require_once('../pages/topmenu-header.php'); ?>
        <!-- End Header Area -->

        <!-- Start Bradcaump area -->
        <div class="ht__bradcaump__area" style="background: rgba(0, 0, 0, 0) url(images/bg/5.jpg) no-repeat scroll center center / cover ;">
            <div class="ht__bradcaump__wrap">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="bradcaump__inner">
                                <nav class="bradcaump-inner">
                                    <a class="breadcrumb-item" href="../trang-chu">Trang Chủ</a>
                                    <span class="brd-separetor"><i class="zmdi zmdi-chevron-right"></i></span>
                                    <span class="breadcrumb-item active">danh sách yêu thích</span>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Bradcaump area -->
        <!-- wishlist-area start -->
        <div class="wishlist-area ptb--100 bg__white">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="wishlist-content">
                            <form action="#">
                                <div class="wishlist-table table-responsive">
                                    <table>
                                        <thead>
                                            <tr>
                                                <th class="product-remove"><span class="nobr">STT</span></th>
                                                <th class="product-thumbnail">Hình ảnh</th>
                                                <th class="product-name"><span class="nobr">tên sản phẩm</span></th>
                                                <th class="product-price"><span class="nobr">đơn giá</span></th>
                                                <th class="product-stock-stauts"><span class="nobr">Số lượng</span></th>
                                                <th class=""><span class="nobr">Thêm vào<br>giỏ hàng</span></th>
                                                <th class="product-remove"><span class="nobr">Gỡ bỏ</span></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $query_sp = $ketnoi->query("SELECT * FROM `yeu_thich` WHERE `taikhoan` = '" . $_SESSION['username'] . "' ORDER BY id_yeuthich DESC");
                                            $stt = 0;
                                            while ($row = mysqli_fetch_array($query_sp)) {
                                                $stt++;
                                                $masp = $row['ma_sp'];
                                                $data_sp = $ketnoi->query("SELECT * FROM `san_pham` WHERE `ma_sp` = '" . $masp . "'")->fetch_array();
                                                if (isset($data_sp['id_sp'])) {
                                                    $giasp = $data_sp['gia_sp'];
                                                    $ténsp = $data_sp['ten_sp'];
                                                    $sl_kho = $data_sp['soluong_sp'];

                                                    //$ténsp = sub_name($ténsp, 20) . '...';
                                                    $img = $data_sp['anh_sp'];
                                                    $img = explode(",", $img)[rand(0, 2)];
                                            ?>
                                                    <tr>
                                                        <td class="product-remove"><a><?= $stt ?></a></td>
                                                        <td class="product-thumbnail"><a href="../product-details/?masp=<?= $masp ?>"><img src="<?= $img ?>" alt="" /></a></td>
                                                        <td class="product-name"><a href="../product-details/?masp=<?= $masp ?>"><?= $ténsp ?></a></td>
                                                        <td class="product-price"><span class="amount"><?= tien($giasp) ?>đ</span></td>
                                                        <td class="product-stock-status"><span class="wishlist-in-stock"><?= $sl_kho ?></span></td>
                                                        <td class="product-add-to-cart" style="width: 38px;"><a href="../wishlist/?themgiohang=<?= $masp ?>" style="font-size: 10px;width: 70px;padding: 3px 3px;">Thêm</a></td>
                                                        <td class="product-remove"><a href="../wishlist/?huyyeuthich=<?= $masp ?>">×</a></td>
                                                    </tr>
                                            <?php
                                                }
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- wishlist-area end -->
        <!-- Start Brand Area -->
        <div class="htc__brand__area bg__cat--4">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="ht__brand__inner">
                            <ul class="brand__list owl-carousel clearfix">
                                <li><a href="#"><img src="../images/brand/1.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/2.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/3.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/4.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/5.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/5.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/1.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/2.png" alt="brand images"></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Brand Area -->
        <!-- Start Banner Area -->
        <div class="htc__banner__area">
            <ul class="banner__list owl-carousel owl-theme clearfix">
                <li><a href="../product-details"><img src="../images/banner/bn-3/1.jpg" alt="banner images"></a></li>
                <li><a href="../product-details"><img src="../images/banner/bn-3/2.jpg" alt="banner images"></a></li>
                <li><a href="../product-details"><img src="../images/banner/bn-3/3.jpg" alt="banner images"></a></li>
                <li><a href="../product-details"><img src="../images/banner/bn-3/4.jpg" alt="banner images"></a></li>
                <li><a href="../product-details"><img src="../images/banner/bn-3/5.jpg" alt="banner images"></a></li>
                <li><a href="../product-details"><img src="../images/banner/bn-3/6.jpg" alt="banner images"></a></li>
                <li><a href="../product-details"><img src="../images/banner/bn-3/1.jpg" alt="banner images"></a></li>
                <li><a href="../product-details"><img src="../images/banner/bn-3/2.jpg" alt="banner images"></a></li>
            </ul>
        </div>
        <!-- End Banner Area -->
        <!-- End Banner Area -->
        <!-- Start Footer Area -->
        <footer id="htc__footer">
            <!-- Start Footer Widget -->
            <div class="footer__container bg__cat--1">
                <div class="container">
                    <div class="row">
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-3 col-sm-6 col-xs-12">
                            <div class="footer">
                                <h2 class="title__line--2">Coming Up</h2>
                                <div class="ft__details">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisizing elit, sed do eiusmod tempor incididunt utlabore et dolore magna aliqua. Út cưng</p>
                                    <div class="ft__social__link">
                                        <ul class="social__link">
                                            <li><a href="#"><i class="icon-social-twitter icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-instagram icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-facebook icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-google icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-linkedin icons"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40">
                            <div class="footer">
                                <h2 class="title__line--2">Information</h2>
                                <div class="ft__inner">
                                    <ul class="ft__list">
                                        <li><a href="#">Về chúng tôi</a></li>
                                        <li><a href="#">Thông tin giao hàng</a></li>
                                        <li><a href="#">Chính sách bảo mật</a></li>
                                        <li><a href="#">Điều khoản & Điều kiện</a></li>
                                        <li><a href="#">sản xuất</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40 smt-40">
                            <div class="footer">
                                <h2 class="title__line--2">tài khoản của tôi</h2>
                                <div class="ft__inner">
                                    <ul class="ft__list">
                                        <li><a href="#">Tài khoản của tôi</a></li>
                                        <li><a href="../cart">Hàng hóa của tôi</a></li>
                                        <li><a href="#">Đăng nhập</a></li>
                                        <li><a href="../wishlist">danh sách yêu thích</a></li>
                                        <li><a href="../checkout">Thanh toán liên tục</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40 smt-40">
                            <div class="footer">
                                <h2 class="title__line--2">giao dịch của chúng tôi</h2>
                                <div class="ft__inner">
                                    <ul class="ft__list">
                                        <li><a href="#">Tài khoản của tôi</a></li>
                                        <li><a href="../cart">Hàng hóa của tôi</a></li>
                                        <li><a href="#">Đăng nhập</a></li>
                                        <li><a href="../wishlist">danh sách yêu thích</a></li>
                                        <li><a href="../checkout">Thanh toán liên tục</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-3 col-sm-6 col-xs-12 xmt-40 smt-40">
                            <div class="footer">
                                <h2 class="title__line--2">BẢN TIN</h2>
                                <div class="ft__inner">
                                    <div class="news__input">
                                        <input type="text" placeholder="Your Mail*">
                                        <div class="send__btn">
                                            <a class="fr__btn" href="#">Gửi thư</a>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                    </div>
                </div>
            </div>
            <!-- End Footer Widget -->
            <!-- Start Copyright Area -->
            <div class="htc__copyright bg__cat--5">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="copyright__inner">
                                <p>Copyright© <a href="https://freethemescloud.com/">Chủ đề miễn phí Đám mây</a>2018. Bảo lưu mọi quyền.</p>
                                <a href="#"><img src="../images/others/shape/paypol.png" alt="payment images"></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Copyright Area -->
        </footer>
        <!-- End Footer Style -->
    </div>
    <!-- Body main wrapper end -->

    <!-- Placed js at the end of the document so the pages load faster -->

    <!-- jquery latest version -->
    <script src="../js/vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap framework js -->
    <script src="../js/bootstrap.min.js"></script>
    <!-- All js plugins included in this file. -->
    <script src="../js/plugins.js"></script>
    <script src="../js/slick.min.js"></script>
    <script src="../js/owl.carousel.min.js"></script>
    <!-- Waypoints.min.js. -->
    <script src="../js/waypoints.min.js"></script>
    <!-- Main js file that contents all jQuery plugins activation. -->
    <script src="../js/main.js"></script>

</body>

</html>