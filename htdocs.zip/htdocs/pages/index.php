<?php
//session_start();
require_once('../admin/config.php');



if (isset($_GET['yeuthich'])) {
    $ma_yt = $_GET['yeuthich'];
    $check_hh = mysqli_num_rows(mysqli_query($ketnoi, "SELECT * FROM yeu_thich WHERE taikhoan ='".$_SESSION['username']."' and `ma_sp` = '".$ma_yt."'"));
    if ($check_hh == 0) {
        $sql_yt = "INSERT INTO `yeu_thich`(`ma_sp`, `taikhoan`) VALUES ('" . $ma_yt . "','" . $_SESSION['username'] . "')";
        $_yt = $ketnoi->query($sql_yt);
        $data_sp = $ketnoi->query("SELECT * FROM `san_pham` WHERE `ma_sp` = '".$ma_yt."'")->fetch_array();
        $luot_yt = $data_sp['sl_yeuthich'];
        $sql_yt = "UPDATE `san_pham` SET `sl_yeuth1' = '" . ($luot_yt+1) . "' WHERE `ma_sp` = '" . $ma_yt . "'";
    }
}


if (!isset($_SESSION['arrgiohang']) or !isset($_SESSION['arrgiohang1'])) {
    $_SESSION['arrgiohang'] = [];
    $_SESSION['arrgiohang1'] = [];
}

if (isset($_GET['themgiohang'])) {
    $data_sp = $ketnoi->query("SELECT * FROM `san_pham` WHERE `ma_sp` = '" . $_GET['themgiohang'] . "'")->fetch_array();
    if ($data_sp['id_sp'] != '') {
        $ma_sp = $_GET['themgiohang'];
        $ten_sp = $data_sp['ten_sp'];
        $sl_sp  = $data_sp['soluong_sp'];
        $gia_sp = $data_sp['gia_sp'];
        $trangthai_sp = $data_sp['trangthai_sp'];

        if (in_array($_GET['themgiohang'], $_SESSION['arrgiohang1'])) {
            for ($cc = 0; $cc < count($_SESSION['arrgiohang']); $cc++) {
                if ($_SESSION['arrgiohang'][$cc]["masp"] == $ma_sp) {
                    $soluong_spht = $_SESSION['arrgiohang'][$cc]["soluong"];
                    $soluong_spht = $soluong_spht + 1;
                    $_SESSION['arrgiohang'][$cc]["soluong"] = $soluong_spht;
                    echo "<script>confirm('Bạn đã thêm [".$soluong_spht."] [ ".$ten_sp." ] vào giỏ hàng.');</script>";
                    break;
                }
            }


        } else {


            array_push($_SESSION['arrgiohang'], array("masp" => $_GET['themgiohang'], "soluong" => "1"));
            array_push($_SESSION['arrgiohang1'],$_GET['themgiohang']);
            echo "<script>confirm('Bạn đã thêm [ ".$ten_sp." ] vào giỏ hàng.');</script>";
        }
    } else {
        echo "<script>confirm('Mã sản phẩm [ " . $_GET['themgiohang'] . " ] không tồn tại.');</script>";
    }
    echo '<meta http-equiv="refresh" content="0;url=../trang-chu">';
}

if (isset($_GET['xoagiohang'])) {
    $xoa = $_GET['xoagiohang'];
    
    $data_sp = $ketnoi->query("SELECT * FROM `san_pham` WHERE `ma_sp` = '" . $_SESSION['arrgiohang1'][$xoa] . "'")->fetch_array();
    $ten_sp = $data_sp['ten_sp'];

    array_splice($_SESSION['arrgiohang'],$xoa, 1);
    array_splice($_SESSION['arrgiohang1'],$xoa, 1);
    echo "<script>confirm('Bạn đã xóa [ ".$ten_sp." ] ra khỏi giỏ hàng giỏ hàng.');</script>";
    echo '<meta http-equiv="refresh" content="0;url=../trang-chu">';
}






//img gioi thieu
$query_sp = $ketnoi->query("SELECT * FROM `san_pham`");
$stt = 0;
$arr_sp = [];
while ($row = mysqli_fetch_array($query_sp)) {
    $stt++;
    $masp = $row['ma_sp'];
    $tensp = $row['ten_sp'];
    $img = $row['anh_sp'];

    //$img = explode(",", $img)[0];
    array_push($arr_sp, array('masp' => $masp, 'tensp' => $tensp, 'png' => $img));
}

$chon_arr_sp = $arr_sp[array_rand($arr_sp, 1)];

$masp_a = $chon_arr_sp['masp'];
$tensp_a = $chon_arr_sp['masp'];
$link_a = $chon_arr_sp['png'];

$link_a_1 = explode(",", $link_a)[0];
$link_a_2 = explode(",", $link_a)[1];
$link_a_3 = explode(",", $link_a)[2];

?>

<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title> Shop Quần Áo Tết || TT Shop || Thương Shop</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Place favicon.ico in the root directory -->
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">


    <!-- All css files are included here. -->
    <!-- Bootstrap fremwork main css -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- Owl Carousel min css -->
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">
    <!-- This core.css file contents all plugings css file. -->
    <link rel="stylesheet" href="../css/core.css">
    <!-- Theme shortcodes/elements style -->
    <link rel="stylesheet" href="../css/shortcode/shortcodes.css">
    <!-- Theme main style -->
    <link rel="stylesheet" href="../style.css">
    <!-- Responsive css -->
    <link rel="stylesheet" href="../css/responsive.css">
    <!-- User style -->
    <link rel="stylesheet" href="../css/custom.css">


    <!-- Modernizr JS -->
    <script src="../js/vendor/modernizr-3.5.0.min.js"></script>
</head>

<body>
    <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>error time</strong> browser. Please <a href="http://browsehappy.com/">nâng cấp trình duyệt của bạn</a>để cải thiện trải nghiệm của bạn.</p>
    <![endif]-->

    <!-- Body main wrapper start -->
    <div class="wrapper">
        <!-- Start Header Style -->
        <?php require_once('../pages/topmenu-header.php'); ?>
        <!-- End Header Area -->


        <!-- End Offset Wrapper -->
        <!-- Start Slider Area -->
        <div class="slider__container slider--one bg__cat--3">
            <div class="slide__container slider__activation__wrap owl-carousel">
                <!-- Start Single Slide -->
                <div class="single__slide animation__style01 slider__fixed--height">
                    <div class="container">
                        <div class="row align-items__center">
                            <div class="col-md-7 col-sm-7 col-xs-12 col-lg-6">
                                <div class="slide">
                                    <div class="slider__inner">
                                        <h2>Bộ sưu tập 2023</h2>
                                        <h1>HỘI TẾT</h1>
                                        <div class="cr__btn">
                                            <a href="../product-details/?masp=<?= $masp_a?>">mua ngay</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-sm-5 col-xs-12 col-md-5">
                                <div class="slide__thumb">
                                    <img src="<?= $link_a_1 ?>" alt="slider images">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Single Slide -->
                <!-- Start Single Slide -->
                <div class="single__slide animation__style01 slider__fixed--height">
                    <div class="container">
                        <div class="row align-items__center">
                            <div class="col-md-7 col-sm-7 col-xs-12 col-lg-6">
                                <div class="slide">
                                    <div class="slider__inner">
                                        <h2>bộ sưu tập 2023</h2>
                                        <h1>Quần Áo đẹp</h1>
                                        <div class="cr__btn">
                                            <a href="../product-details/?masp=<?= $masp_a?>">mua ngay</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-sm-5 col-xs-12 col-md-5">
                                <div class="slide__thumb">
                                    <img src="<?= $link_a_2 ?>" alt="slider images">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Single Slide -->
                <!-- Start Single Slide -->
                <div class="single__slide animation__style01 slider__fixed--height">
                    <div class="container">
                        <div class="row align-items__center">
                            <div class="col-md-7 col-sm-7 col-xs-12 col-lg-6">
                                <div class="slide">
                                    <div class="slider__inner">
                                        <h2>bộ sưu tập 2018</h2>
                                        <h1>Năm mới hạnh phúc</h1>
                                        <div class="cr__btn">
                                            <a href="../product-details/?masp=<?= $masp_a?>">mua ngay</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-sm-5 col-xs-12 col-md-5">
                                <div class="slide__thumb">
                                    <img src="<?= $link_a_3 ?>" alt="slider images">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Single Slide -->
            </div>
        </div>
        <!-- Start Slider Area -->
        <!-- Start Category Area -->
        <section class="htc__category__area ptb--100">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="section__title--2 text-center">
                            <h2 class="title__line">Sản Phẩm Mới</h2>
                            <!--p>Nhưng tôi phải giải thích cho bạn hiểu tại sao tất cả ý tưởng sai lầm này</p-->
                        </div>
                    </div>
                </div>
                <div class="htc__product__container">
                    <div class="row">
                        <div class="product__list clearfix mt--30">
                            <?php



                            $query_sp = $ketnoi->query("SELECT * FROM `san_pham` ORDER BY `ngay_sp` DESC");
                            $stt = 0;
                            while ($row = mysqli_fetch_array($query_sp)) {
                                $stt++;
                                $masp = $row['ma_sp'];
                                $giasp = $row['gia_sp'];
                                $ténsp = $row['ten_sp'];
                                $ténsp = sub_name($ténsp, 20) . '...';
                                $img = $row['anh_sp'];
                                $img = explode(",", $img)[rand(0, 2)];
                                $trangthai = $row['trangthai_sp'];
                                $hienthi = "Hiển thị";
                                if ($trangthai == 1) {

                            ?>
                                    <!-- Start Single Category -->
                                    <div class="col-md-4 col-lg-3 col-sm-4 col-xs-12" >
                                        <div class="category">
                                            <div class="ht__cat__thumb" >
                                                <a href="../product-details/?masp=<?= $masp ?>">
                                                    <img src="<?= $img ?>" alt="product images">
                                                </a>
                                            </div>
                                            <div class="fr__hover__info">
                                                <ul class="product__action">
                                                    <li onclick="themyeuthich('<?= $masp ?>')"><a><i class="icon-heart icons"></i></a></li>

                                                    <li onclick="themvaogiohang('<?= $masp ?>')"><a><i class="icon-handbag icons"></a></i></li>

                                                    
                                                </ul>
                                            </div>
                                            <div class="fr__product__inner">
                                                <h4><a href="../product-details/?masp=<?= $masp ?>"><?= $ténsp ?></a></h4>
                                                <ul class="fr__pro__prize">
                                                    <li class="old__prize"><del><?= tien($giasp + 45000) ?></del>đ</li>
                                                    <li><?= tien($giasp) ?>đ</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Category -->

                            <?php }
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Category Area -->
        <!-- Start Prize Good Area -->
        <section class="htc__good__sale bg__cat--3">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                        <div class="fr__prize__inner">
                            <h2>Trái ngược với niềm tin phổ biến biến chỉ đơn giản là rand.</h2>
                            <h3>Giáo sư tại Đại học Hamp Deny Dney.</h3>
                            <a class="fr__btn" href="#">Đọc thêm</a>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                        <div class="prize__inner">
                            <div class="prize__thumb">
                                <img src="../images/banner/big-img/1.png" alt="banner images">
                            </div>
                            <div class="banner__info">
                                <div class="pointer__tooltip pointer--3 align-left">
                                    <div class="tooltip__box">
                                        <h4>Chú giải công cụ bên trái</h4>
                                        <p>Lorem ipsum pisaci volupt atem accusa saes ntisdumtiu loperm asaerks.</p>
                                    </div>
                                </div>
                                <div class="pointer__tooltip pointer--4 align-top">
                                    <div class="tooltip__box">
                                        <h4>Chú giải công cụ đầu tiên</h4>
                                        <p>Lorem ipsum pisaci volupt atem accusa saes ntisdumtiu loperm asaerks.</p>
                                    </div>
                                </div>
                                <div class="pointer__tooltip pointer--5 align-bottom">
                                    <div class="tooltip__box">
                                        <h4>Công cụ giải thích bên dưới cùng</h4>
                                        <p>Lorem ipsum pisaci volupt atem accusa saes ntisdumtiu loperm asaerks.</p>
                                    </div>
                                </div>
                                <div class="pointer__tooltip pointer--6 align-top">
                                    <div class="tooltip__box">
                                        <h4>Công cụ giải thích bên dưới cùng</h4>
                                        <p>Lorem ipsum pisaci volupt atem accusa saes ntisdumtiu loperm asaerks.</p>
                                    </div>
                                </div>
                                <div class="pointer__tooltip pointer--7 align-top">
                                    <div class="tooltip__box">
                                        <h4>Công cụ giải thích bên dưới cùng</h4>
                                        <p>Lorem ipsum pisaci volupt atem accusa saes ntisdumtiu loperm asaerks.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Prize Good Area -->
        <!-- Start Product Area -->
        <section class="ftr__product__area ptb--100">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="section__title--2 text-center">
                            <h2 class="title__line">Top yêu thích </h2>
                            <!--p>Nhưng tôi phải giải thích cho bạn hiểu tại sao tất cả ý tưởng sai lầm này</p-->
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="product__wrap clearfix">

                        <?php



                        $query_sp = $ketnoi->query("SELECT * FROM `san_pham` ORDER BY `sl_yeuthich` ASC");
                        $stt = 0;
                        while ($row = mysqli_fetch_array($query_sp)) {
                            $stt++;
                            if ($stt == 5) {
                                break;
                            }

                            $masp = $row['ma_sp'];
                            $giasp = $row['gia_sp'];
                            $ténsp = $row['ten_sp'];
                            $ténsp = sub_name($ténsp, 20) . '...';
                            $img = $row['anh_sp'];
                            $img = explode(",", $img)[rand(0, 2)];
                            $trangthai = $row['trangthai_sp'];
                            $hienthi = "Hiển thị";
                            if ($trangthai == 1) {

                        ?>

                                <!-- Start Single Category -->
                                <div class="col-md-4 col-lg-3 col-sm-4 col-xs-12">
                                    <div class="category">
                                        <div class="ht__cat__thumb">
                                            <a href="../product-details/?masp=<?= $masp ?>">
                                                <img src="<?= $img ?>" alt="product images">
                                            </a>
                                        </div>
                                        <div class="fr__hover__info">
                                            <ul class="product__action">
                                                <li onclick="themyeuthich('<?= $masp ?>')"><a><i class="icon-heart icons"></i></a></li>

                                                <li onclick="themvaogiohang('<?= $masp ?>')"><a><i class="icon-handbag icons"></a></i></li>

                                                
                                            </ul>
                                        </div>
                                        <div class="fr__product__inner">
                                            <h4><a href="../product-details/?masp=<?= $masp ?>"><?= $ténsp ?></a></h4>
                                            <ul class="fr__pro__prize">
                                                <li class="old__prize"><del><?= tien($giasp + 45000) ?></del>đ</li>
                                                <li><?= tien($giasp) ?>đ</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Single Category -->
                        <?php
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Product Area -->
        <!-- Start Testimonial Area -->
        <section class="htc__testimonial__area bg__cat--4">
            <div class="container">
                <div class="row">
                    <div class="ht__testimonial__activation clearfix">
                        <!-- Start Single Testimonial -->
                        <div class="col-lg-6 col-md-6 single__tes">
                            <div class="testimonial">
                                <div class="testimonial__thumb">
                                    <img src="../images/test/client/3.png" alt="testimonial images" style="width: 89px;">
                                </div>
                                <div class="testimonial__details">
                                    <h4><a href="#">Chúc Mừng Năm Mới</a></h4>
                                    <p>Chào năm mới. Chào đón những điều tươi đẹp. Chào 365 ngày hạnh phúc mong năm mới này bạn và tôi cùng gặt hái nhiều thành công. Gặt hái nhiều những quả ngọt yêu thương mà năm vừa qua mình đã và đang ấp ủ. Chúc mừng năm mới.</p>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Testimonial -->
                        <!-- Start Single Testimonial -->
                        <div class="col-lg-6 col-md-6 single__tes">
                            <div class="testimonial">
                                <div class="testimonial__thumb">
                                    <img src="../images/test/client/4.png" alt="testimonial images" style="width: 89px;">
                                </div>
                                <div class="testimonial__details">
                                    <h4><a href="#">Sale Ngày Tết</a></h4>
                                    <p>Từ ngày 22-29 tết chúng tôi Sale tất cả sản phẩm với một nữa giá, sẽ là quà tặng đầu năm dành đến các bạn, chúc các bạn năm mới vui vẻ.</p>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Testimonial -->
                        <!-- Start Single Testimonial -->
                        <div class="col-lg-6 col-md-6 single__tes">
                            <div class="testimonial">
                                <div class="testimonial__thumb">
                                    <img src="../images/test/client/3.png" alt="testimonial images" style="width: 89px;">
                                </div>
                                <div class="testimonial__details">
                                    <h4><a href="#">Chúc Mừng Năm Mới</a></h4>
                                    <p>Chào năm mới. Chào đón những điều tươi đẹp. Chào 365 ngày hạnh phúc mong năm mới này bạn và tôi cùng gặt hái nhiều thành công. Gặt hái nhiều những quả ngọt yêu thương mà năm vừa qua mình đã và đang ấp ủ. Chúc mừng năm mới.</p>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Testimonial -->
                        <!-- Start Single Testimonial -->
                        <div class="col-lg-6 col-md-6 single__tes">
                            <div class="testimonial">
                                <div class="testimonial__thumb">
                                    <img src="../images/test/client/4.png" alt="testimonial images" style="width: 89px;">
                                </div>
                                <div class="testimonial__details">
                                    <h4><a href="#">Sale Ngày Tết</a></h4>
                                    <p>Từ ngày 22-29 tết chúng tôi Sale tất cả sản phẩm với một nữa giá, sẽ là quà tặng đầu năm dành đến các bạn, chúc các bạn năm mới vui vẻ.</p>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Testimonial -->
                        <!-- Start Single Testimonial -->
                        <div class="col-lg-6 col-md-6 single__tes">
                            <div class="testimonial">
                                <div class="testimonial__thumb">
                                    <img src="../images/test/client/3.png" alt="testimonial images" style="width: 89px;">
                                </div>
                                <div class="testimonial__details">
                                    <h4><a href="#">Chúc Mừng Năm Mới</a></h4>
                                    <p>Chào năm mới. Chào đón những điều tươi đẹp. Chào 365 ngày hạnh phúc mong năm mới này bạn và tôi cùng gặt hái nhiều thành công. Gặt hái nhiều những quả ngọt yêu thương mà năm vừa qua mình đã và đang ấp ủ. Chúc mừng năm mới.</p>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Testimonial -->
                        <!-- Start Single Testimonial -->
                        <div class="col-lg-6 col-md-6 single__tes">
                            <div class="testimonial">
                                <div class="testimonial__thumb">
                                    <img src="../images/test/client/4.png" alt="testimonial images" style="width: 89px;">
                                </div>
                                <div class="testimonial__details">
                                    <h4><a href="#">Sale Ngày Tết</a></h4>
                                    <p>Từ ngày 22-29 tết chúng tôi Sale tất cả sản phẩm với một nữa giá, sẽ là quà tặng đầu năm dành đến các bạn, chúc các bạn năm mới vui vẻ.</p>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Testimonial -->
                    </div>
                </div>
            </div>
        </section>
        <!-- End Testimonial Area -->
        <!-- Start Top Rated Area -->
        <section class="top__rated__area bg__white pt--100 pb--110">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section__title--2 text-center">
                            <h2 class="title__line">Top Bán Chạy</h2>
                            <!--p>Nhưng tôi phải giải thích cho bạn</p--->
                        </div>
                    </div>
                </div>
                <div class="row mt--20">
                    <?php
                    $query_sp = $ketnoi->query("SELECT * FROM `san_pham` ORDER BY `daban_sp` ASC");
                    $stt = 0;
                    while ($row = mysqli_fetch_array($query_sp)) {
                        $stt++;
                        if ($stt == 4) {
                            break;
                        }

                        $masp = $row['ma_sp'];
                        $giasp = $row['gia_sp'];
                        $ténsp = $row['ten_sp'];
                        $ténsp = sub_name($ténsp, 20) . '...';
                        $img = $row['anh_sp'];
                        $img = explode(",", $img)[rand(0, 2)];
                        $trangthai = $row['trangthai_sp'];
                        $hienthi = "Hiển thị";
                        if ($trangthai == 1) {
                    ?>
                            <!-- Start Single Product -->
                            <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                                <div class="htc__best__product">
                                    <div class="htc__best__pro__thumb">
                                        <a href="../product-details/?masp=<?= $masp ?>">
                                            <img src="<?= $img ?>" alt="small product">
                                        </a>
                                    </div>
                                    <div class="htc__best__product__details">
                                        <h2><a href="../product-details/?masp=<?= $masp ?>"><?= $ténsp ?></a></h2>
                                        <!--ul class="rating">
                                            <li><i class="icon-star icons"></i></li>
                                            <li><i class="icon-star icons"></i></li>
                                            <li><i class="icon-star icons"></i></li>
                                            <li class="old"><i class="icon-star icons"></i></li>
                                            <li class="old"><i class="icon-star icons"></i></li>
                                        </ul-->
                                        <ul class="top__pro__prize">
                                            <li class="old__prize"><del><?= tien($giasp + 45000) ?></del>đ</li>
                                            <li><?= tien($giasp) ?>đ</li>
                                        </ul>
                                        <div class="best__product__action">
                                            <ul class="product__action--dft">
                                                <!--li><a href="../wishlist"><i class="icon-heart icons"></i></a></li-->
                                                <li onclick="themyeuthich('<?= $masp ?>')"><a><i class="icon-heart icons"></i></a></li>
                                                <li onclick="themvaogiohang('<?= $masp ?>')"><a><i class="icon-handbag icons"></a></i></li>
                                                
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Product -->
                    <?php
                        }
                    }
                    ?>

                </div>
            </div>
        </section>
        <!-- End Top Rated Area -->
        <!-- Start Brand Area -->
        <div class="htc__brand__area bg__cat--4">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="ht__brand__inner">
                            <ul class="brand__list owl-carousel clearfix">
                                <li><a href="#"><img src="../images/brand/1.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/2.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/3.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/4.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/5.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/5.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/1.png" alt="brand images"></a></li>
                                <li><a href="#"><img src="../images/brand/2.png" alt="brand images"></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Brand Area -->
        <!-- End Banner Area -->
        <!-- Start Footer Area -->
        <footer id="htc__footer">
            <!-- Start Footer Widget -->
            <div class="footer__container bg__cat--1">
                <div class="container">
                    <div class="row">
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-3 col-sm-6 col-xs-12">
                            <div class="footer">
                                <h2 class="title__line--2">Coming Up</h2>
                                <div class="ft__details">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisizing elit, sed do eiusmod tempor incididunt utlabore et dolore magna aliqua. Út cưng</p>
                                    <div class="ft__social__link">
                                        <ul class="social__link">
                                            <li><a href="#"><i class="icon-social-twitter icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-instagram icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-facebook icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-google icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-linkedin icons"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40">
                            <div class="footer">
                                <h2 class="title__line--2">Information</h2>
                                <div class="ft__inner">
                                    <ul class="ft__list">
                                        <li><a href="#">Về chúng tôi</a></li>
                                        <li><a href="#">Thông tin giao hàng</a></li>
                                        <li><a href="#">Chính sách bảo mật</a></li>
                                        <li><a href="#">Điều khoản & Điều kiện</a></li>
                                        <li><a href="#">sản xuất</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40 smt-40">
                            <div class="footer">
                                <h2 class="title__line--2">tài khoản của tôi</h2>
                                <div class="ft__inner">
                                    <ul class="ft__list">
                                        <li><a href="#">Tài khoản của tôi</a></li>
                                        <li><a href="../product-details/?masp=<?= $masp_a?>">Hàng hóa của tôi</a></li>
                                        <li><a href="#">Đăng nhập</a></li>
                                        <li><a href="../wishlist">danh sách yêu thích</a></li>
                                        <li><a href="../checkout">Thanh toán liên tục</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-2 col-sm-6 col-xs-12 xmt-40 smt-40">
                            <div class="footer">
                                <h2 class="title__line--2">giao dịch của chúng tôi</h2>
                                <div class="ft__inner">
                                    <ul class="ft__list">
                                        <li><a href="#">Tài khoản của tôi</a></li>
                                        <li><a href="../product-details/?masp=<?= $masp_a?>">Hàng hóa của tôi</a></li>
                                        <li><a href="#">Đăng nhập</a></li>
                                        <li><a href="../wishlist">danh sách yêu thích</a></li>
                                        <li><a href="../checkout">Thanh toán liên tục</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-3 col-sm-6 col-xs-12 xmt-40 smt-40">
                            <div class="footer">
                                <h2 class="title__line--2">BẢN TIN</h2>
                                <div class="ft__inner">
                                    <div class="news__input">
                                        <input type="text" placeholder="Your Mail*">
                                        <div class="send__btn">
                                            <a class="fr__btn" href="#">Gửi thư</a>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                    </div>
                </div>
            </div>
            <!-- End Footer Widget -->
            <!-- Start Copyright Area -->
            <div class="htc__copyright bg__cat--5">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="copyright__inner">
                                <p>Copyright© <a href="https://freethemescloud.com/">Chủ đề miễn phí Đám mây</a>2018. Bảo lưu mọi quyền.</p>
                                <a href="#"><img src="../images/others/shape/paypol.png" alt="payment images"></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Copyright Area -->
        </footer>
        <!-- End Footer Style -->
    </div>
    <!-- Body main wrapper end -->

    <!-- Placed js at the end of the document so the pages load faster -->

    <!-- jquery latest version -->
    <script src="../js/vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap framework js -->
    <script src="../js/bootstrap.min.js"></script>
    <!-- All js plugins included in this file. -->
    <script src="../js/plugins.js"></script>
    <script src="../js/slick.min.js"></script>
    <script src="../js/owl.carousel.min.js"></script>
    <!-- Waypoints.min.js. -->
    <script src="../js/waypoints.min.js"></script>
    <!-- Main js file that contents all jQuery plugins activation. -->
    <script src="../js/main.js"></script>







    <script type="text/javascript">
        var bits = 90;
        var speed = 33;
        var bangs = 7;
        var colours = new Array("#03f", "#f03", "#fff", "#f7efa1", "#0cf", "#f93", "#f0c", "#fff");
        var bangheight = new Array();
        var intensity = new Array();
        var colour = new Array();
        var Xpos = new Array();
        var Ypos = new Array();
        var dX = new Array();
        var dY = new Array();
        var stars = new Array();
        var decay = new Array();
        var swide = 800;
        var shigh = 600;
        var boddie;
        window.onload = function() {
            if (document.getElementById) {
                var i;
                boddie = document.createElement("div");
                boddie.style.position = "fixed";
                boddie.style.top = "0px";
                boddie.style.left = "0px";
                boddie.style.overflow = "visible";
                boddie.style.width = "1px";
                boddie.style.height = "1px";
                boddie.style.backgroundColor = "transparent";
                document.body.appendChild(boddie);
                set_width();
                for (i = 0; i < bangs; i++) {
                    write_fire(i);
                    launch(i);
                    setInterval('stepthrough(' + i + ')', speed);
                }
            }
        }

        function write_fire(N) {
            var i, rlef, rdow;
            stars[N + 'r'] = createDiv('|', 12);
            boddie.appendChild(stars[N + 'r']);
            for (i = bits * N; i < bits + bits * N; i++) {
                stars[i] = createDiv('*', 13);
                boddie.appendChild(stars[i]);
            }
        }

        function createDiv(char, size) {
            var div = document.createElement("div");
            div.style.font = size + "px monospace";
            div.style.position = "absolute";
            div.style.backgroundColor = "transparent";
            div.appendChild(document.createTextNode(char));
            return (div);
        }

        function launch(N) {
            colour[N] = Math.floor(Math.random() * colours.length);
            Xpos[N + "r"] = swide * 0.5;
            Ypos[N + "r"] = shigh - 5;
            bangheight[N] = Math.round((0.5 + Math.random()) * shigh * 0.4);
            dX[N + "r"] = (Math.random() - 0.5) * swide / bangheight[N];
            if (dX[N + "r"] > 1.25) stars[N + "r"].firstChild.nodeValue = "/";
            else if (dX[N + "r"] < -1.25) stars[N + "r"].firstChild.nodeValue = "\\";
            else stars[N + "r"].firstChild.nodeValue = "|";
            stars[N + "r"].style.color = colours[colour[N]];
        }

        function bang(N) {
            var i, Z, A = 0;
            for (i = bits * N; i < bits + bits * N; i++) {
                Z = stars[i].style;
                Z.left = Xpos[i] + "px";
                Z.top = Ypos[i] + "px";
                if (decay[i]) decay[i]--;
                else A++;
                if (decay[i] == 15) Z.fontSize = "10px";
                else if (decay[i] == 7) Z.fontSize = "2px";
                else if (decay[i] == 1) Z.visibility = "hidden";
                Xpos[i] += dX[i];
                Ypos[i] += (dY[i] += 1.25 / intensity[N]);
            }
            if (A != bits) setTimeout("bang(" + N + ")", speed);
        }

        function stepthrough(N) {
            var i, M, Z;
            var oldx = Xpos[N + "r"];
            var oldy = Ypos[N + "r"];
            Xpos[N + "r"] += dX[N + "r"];
            Ypos[N + "r"] -= 4;
            if (Ypos[N + "r"] < bangheight[N]) {
                M = Math.floor(Math.random() * 3 * colours.length);
                intensity[N] = 5 + Math.random() * 4;
                for (i = N * bits; i < bits + bits * N; i++) {
                    Xpos[i] = Xpos[N + "r"];
                    Ypos[i] = Ypos[N + "r"];
                    dY[i] = (Math.random() - 0.5) * intensity[N];
                    dX[i] = (Math.random() - 0.5) * (intensity[N] - Math.abs(dY[i])) * 1.25;
                    decay[i] = 25 + Math.floor(Math.random() * 25);
                    Z = stars[i];
                    if (M < colours.length) Z.style.color = colours[i % 2 ? colour[N] : M];
                    else if (M < 2 * colours.length) Z.style.color = colours[colour[N]];
                    else Z.style.color = colours[i % colours.length];
                    Z.style.fontSize = "20px";
                    Z.style.visibility = "visible";
                }
                bang(N);
                launch(N);
            }
            stars[N + "r"].style.left = oldx + "px";
            stars[N + "r"].style.top = oldy + "px";
        }
        window.onresize = set_width;

        function set_width() {
            var sw_min = 999999;
            var sh_min = 999999;
            if (document.documentElement && document.documentElement.clientWidth) {
                if (document.documentElement.clientWidth > 0) sw_min = document.documentElement.clientWidth;
                if (document.documentElement.clientHeight > 0) sh_min = document.documentElement.clientHeight;
            }
            if (typeof(self.innerWidth) != "undefined" && self.innerWidth) {
                if (self.innerWidth > 0 && self.innerWidth < sw_min) sw_min = self.innerWidth;
                if (self.innerHeight > 0 && self.innerHeight < sh_min) sh_min = self.innerHeight;
            }
            if (document.body.clientWidth) {
                if (document.body.clientWidth > 0 && document.body.clientWidth < sw_min) sw_min = document.body.clientWidth;
                if (document.body.clientHeight > 0 && document.body.clientHeight < sh_min) sh_min = document.body.clientHeight;
            }
            if (sw_min == 999999 || sh_min == 999999) {
                sw_min = 800;
                sh_min = 600;
            }
            swide = sw_min;
            shigh = sh_min;
        }

        function themvaogiohang(x) {
            window.location = "../trang-chu/?themgiohang=" + x;
            // get('../product-grid/', {
            //     themgiohang: x
            // })
            // .then(response => {
            //     // Do something with response.
            // });
        }

        function themyeuthich(x){
            if(<?=isset($_SESSION['username'])?"1":"0"?> == 0){
                confirm('Bạn phải đăng nhập để thực hiện thao tác này.');
                window.location = "../dang-nhap";
            }else{
                confirm('Đã thêm ['+x+'] vào danh sách yêu thích.');
                $.get("../trang-chu/?yeuthich=" + x);
            }
        }
    </script>



</body>

</html>