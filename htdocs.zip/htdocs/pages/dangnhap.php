<?php
//ession_start();
require_once('../admin/config.php');


$user  = "";
$pass  = "";

if (!isset($_SESSION['muahang'])) {
    $_SESSION['muahang'] = 0;
}


if (isset($_POST['dangnhap'])) {
    $user  =  xoadau(addslashes(strip_tags($_POST['username'])));
    $pass  = xoadau(addslashes(strip_tags($_POST['password'])));


    if (strlen($user) < 5) {
        echo "<script>confirm('Độ dài tài khoản phải lớn hơn 5.');</script>";
    } elseif (strlen($pass) < 5) {
        echo "<script>confirm('Độ dài mật khẩu phải lớn hơn 5.');</script>";
    } elseif ($user != $_POST['username']) {
        echo "<script>confirm('Tài khoản thoại không hợp lệ.');</script>";
    } elseif ($pass != $_POST['password']) {
        echo "<script>confirm('Mật khẩu không hợp lệ.');</script>";
    } else {
        $check = $ketnoi->query("SELECT * FROM users WHERE taikhoan ='$user'")->fetch_array();
        if (empty($check) or $check['matkhau'] != $pass) {
            echo "<script>confirm('Tài khoản hoặc mật khẩu sai.');</script>";
        } else {
            $_SESSION['username'] = $check['taikhoan'];
            echo "<script>confirm('Đăng nhập thàng công ".$_SESSION['username'].".');</script>";

            if($_SESSION['muahang'] == 1){
                echo '<meta http-equiv="refresh" content="1;url=../checkout">';
            }else{
                echo '<meta http-equiv="refresh" content="1;url=../trang-chu">';
            }
        }
    }
}

?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Liên hệ || Asbab - Mẫu HTML5 thương mại điện tử</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Place favicon.ico in the root directory -->
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    

    <!-- All css files are included here. -->
    <!-- Bootstrap fremwork main css -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- Owl Carousel min css -->
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">
    <!-- This core.css file contents all plugings css file. -->
    <link rel="stylesheet" href="../css/core.css">
    <!-- Theme shortcodes/elements style -->
    <link rel="stylesheet" href="../css/shortcode/shortcodes.css">
    <!-- Theme main style -->
    <link rel="stylesheet" href="../style.css">
    <!-- Responsive css -->
    <link rel="stylesheet" href="../css/responsive.css">
    <!-- User style -->
    <link rel="stylesheet" href="../css/custom.css">


    <!-- Modernizr JS -->
    <script src="../js/vendor/modernizr-3.5.0.min.js"></script>
</head>

<body>
    <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>error time</strong> browser. Please <a href="http://browsehappy.com/">nâng cấp trình duyệt của bạn</a>để cải thiện trải nghiệm của bạn.</p>
    <![endif]-->  

    <!-- Body main wrapper start -->
    <div class="wrapper">
        <!-- Start Contact Area -->
        <section class="htc__contact__area ptb--100 bg__white">
            <div class="container">
                <div class="row">
                        <div class="col-xs-12">
                            <form method="post">
                                <div class="single-contact-form">
                                    <div class="contact-box subject">
                                        <input type="text" name="username" placeholder="Nhập tên tài khoản*" value="<?=$user?>">
                                    </div>
                                </div>
                                <div class="single-contact-form">
                                    <div class="contact-box subject">
                                        <input type="password" name="password" placeholder="Nhập mật khẩu *" value="<?=$pass?>">
                                    </div>
                                </div>
                                <div class="contact-btn" >
                                    <button type="submit" class="fv-btn" name="dangnhap">ĐĂNG NHẬP</button>
                                    <br/><br/>
                                    <p>Nếu có tài khoản bấm <a href = "../dang-ky" style="color: #f00;">vào đây</a> để đăng ký tài khoản mới</p>
                                    <p>Hoặc bấm <a href = "../trang-chu" style="color: #f00;">vào đây</a> để quay về trang chủ</p>
                                </div>
                            </form>
                            <div class="form-output">
                                <p class="form-messege"></p>
                            </div>
                        </div>
                    </div> 
                </div>
            </div>
        </section>
        <!-- End Contact Area -->
    </div>
    <!-- Body main wrapper end -->

    <!-- Placed js at the end of the document so the pages load faster -->

    <!-- jquery latest version -->
    <script src="../js/vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap framework js -->
    <script src="../js/bootstrap.min.js"></script>
    <!-- All js plugins included in this file. -->
    <script src="../js/plugins.js"></script>
    <script src="../js/slick.min.js"></script>
    <script src="../js/owl.carousel.min.js"></script>
    <script src="../js/ajax-mail.js"></script>
    <!-- Waypoints.min.js. -->
    <script src="../js/waypoints.min.js"></script>
    <!-- Main js file that contents all jQuery plugins activation. -->
    <script src="../js/main.js"></script>

</body>

</html>